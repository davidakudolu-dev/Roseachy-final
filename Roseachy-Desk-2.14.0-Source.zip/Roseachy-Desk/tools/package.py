#!/usr/bin/env python3
"""Package the static Cloudflare Pages site and the complete reviewed source."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"
STATIC = [
    "index.html", "manifest.json", "sw.js", "_headers", "_redirects",
    "js/pwa.js", "js/android-sync-files.js",
    "icons/roseachy-logo.svg", "icons/icon-48.png", "icons/icon-192.png",
    "icons/icon-512.png", "icons/icon-maskable-512.png", "icons/apple-touch-icon.png",
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive(target, files, prefix=""):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for relative in sorted(files):
            file = ROOT / relative
            if file.is_symlink() or not file.is_file():
                raise RuntimeError(f"Expected a regular source file: {relative}")
            info = zipfile.ZipInfo(prefix + relative, date_time=(2026, 10, 20, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, file.read_bytes())
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:
            raise RuntimeError(f"Archive integrity failed: {target.name}")
        assert set(z.namelist()) == {prefix + p for p in files}
        for relative in files:
            assert digest(z.read(prefix + relative)) == digest((ROOT / relative).read_bytes())


def main():
    OUT.mkdir(exist_ok=True)
    # Runtime is the original static Pages architecture. No Workers build or server bundle.
    deployment = OUT / "Roseachy-Desk-2.14.0-Cloudflare-Pages.zip"
    archive(deployment, STATIC)
    preview = OUT / "Roseachy-Desk-2.14.0-Preview.zip"
    archive(preview, ["index.html"])
    preview_html = OUT / "Roseachy-Desk-2.14.0-Preview.html"
    preview_html.write_bytes((ROOT / "index.html").read_bytes())
    source_files = []
    for file in ROOT.rglob("*"):
        relative = file.relative_to(ROOT)
        if any(p in {".git", "node_modules", ".test-results", "dist", "__pycache__"} for p in relative.parts):
            continue
        if file.is_file():
            source_files.append(relative.as_posix())
    source = OUT / "Roseachy-Desk-2.14.0-Source.zip"
    archive(source, source_files, "Roseachy-Desk/")
    manifest = {
        "release": "2.14.0-credit-edit",
        "artifacts": [{"name": f.name, "sha256": digest(f.read_bytes()), "bytes": f.stat().st_size}
                      for f in [deployment, source, preview, preview_html]],
        "deployment_files": {p: digest((ROOT / p).read_bytes()) for p in sorted(STATIC)},
    }
    (OUT / "SHA256-MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"deployment_files": len(STATIC), "source_files": len(source_files),
                      "artifacts": manifest["artifacts"]}, indent=2))


if __name__ == "__main__":
    main()
