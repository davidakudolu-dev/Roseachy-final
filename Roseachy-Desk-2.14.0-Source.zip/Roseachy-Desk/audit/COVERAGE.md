# Requested phase coverage

| Requested phase | Evidence / boundary |
|---|---|
| 1 Baseline and architecture | Preserved 2.13.0 runtime, initial 80-check summary, DEPENDENCY_MAP.md |
| 2 Static inspection | ESLint static-findings.json, source-boundary and DOM identity checks |
| 3 Dataset preparation | SYS-01–03: supported product, supplier and customer creation |
| 4 Business operations | SYS-04–05 and original workflow/integrity suites; not every operation combination |
| 5 Inventory | Independent per-product reconciliation, pack boundaries, invalid quantities, repeated action tests |
| 6 Credit | Credit limits, partial/final payment, concurrency, stock/revenue invariants and original regression cases |
| 7 Financial | FIN-01–04 and original integrity/owner-confirmation cases; separate Bank A/B unsupported |
| 8 Multi-device | Existing signed sync suite plus seven four-context cases; no physical devices |
| 9 Storage and recovery | Large backup round trips, fallback storage, abort/reload injection, original legacy restore cases |
| 10 UI/mobile | Six required viewports, navigation/interaction samples; 440 controls not individually certified |
| 11 Themes/contrast | Ten themes, two modes, eight sampled screens; not all dynamic populated states |
| 12 Performance | Three product sizes, two large ledger sizes, latency/heap samples; no long-duration leak proof |
| 13 PWA/Cloudflare | Real Chromium service-worker offline test and verified Pages archive; no production deployment |
| 14 Failures | Invalid inputs, persistent storage abort, save interruption, sync tampering and repeated actions |
| 15 Repairs | Ten defect entries, exact index.patch and targeted executable checks |
| 16 Regression | Full final runner and per-suite results; unrun acceptance areas disclosed |
| 17 Consistency | Stock, cash, revenue, credit, restore and sync equality assertions; sampled business state |
| 18 Delivery | Audit report, verification, defect/change register, source/runtime/preview archives, hashes |

A passing suite does not convert its entire phase into exhaustive certification. The release remains not fully verified for the documented acceptance gaps.
