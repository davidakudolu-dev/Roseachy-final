# Roseachy Desk 2.13.1 — system audit

This release repairs verified inventory, import, persistence, synchronization, privacy, contrast and performance defects in the 2.13.0 reference-theme build. It preserves the static application architecture and existing ten themes.

**Status: not fully verified.** Automated Chromium regression evidence is included; physical devices, all input methods, and production Cloudflare behavior still require checks. Read `AUDIT_REPORT.md` for measured outcomes and limits.

## Run and deploy

Extract the Cloudflare Pages ZIP and upload its 13 root runtime files using Pages Direct Upload. No build command, server bundle, Worker or production dependency is needed. This release has not been deployed to Cloudflare.

For local development, run `python3 -m http.server 8014` from the extracted project directory. The standalone HTML is a visual preview; PWA installation and offline operation require the complete runtime served on HTTPS or localhost.

## Reproduce validation

Use Node.js 24+, Python 3 and Chromium:

```sh
npm ci --prefix tests
npm test --prefix tests
python3 tools/package.py
```

Set `CHROMIUM_PATH` if Chromium is not at `/usr/bin/chromium`. Tests start their own HTTP server and use isolated synthetic browser data. Do not import audit fixtures into a real business profile. No credentials are required for the local test workflow.

See `tests/README.md`, `AUDIT_REPORT.md`, `CHANGELOG.md` and `DEPENDENCY_MAP.md`. `audit/baseline` preserves the previous runtime and earlier evidence. `audit/final` contains this release's results; test hooks are absent from production HTML.
