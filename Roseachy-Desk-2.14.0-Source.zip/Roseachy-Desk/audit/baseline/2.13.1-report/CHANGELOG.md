# 2.13.1-system-audit — 2026-10-20

- Return a clear rejected-save outcome when another inventory operation is busy.
- Reject invalid numeric bulk-import fields; preserve legacy pack arithmetic and expiry fields.
- Commit supplier edits atomically and retain input after storage failure.
- Return the sanitized enrollment checkpoint and exclude already-accounted events from outgoing updates.
- Exclude local day fingerprints containing private transaction metadata from shared checkpoints.
- Cache parsed product names and unchanged duplicate comparisons without relaxing conflict checks.
- Repair sampled text contrast using a separate screen-only stylesheet and theme-derived colors.
- Correct tests that previously selected nonexistent lowercase tab identifiers, add visible-panel assertions, and extend business, failure, reconciliation, four-device and performance simulations.

No transaction migration, destructive cleanup, new runtime dependency or account-model change is introduced. The private Financial Desk remains a single Business Bank account.
