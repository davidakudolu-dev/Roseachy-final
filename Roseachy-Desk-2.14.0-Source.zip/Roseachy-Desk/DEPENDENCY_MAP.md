# Runtime and audit dependency map

| Boundary | Responsibilities / dependencies |
|---|---|
| index.html | Existing UI, theme engine, business calculations, inventory journal, credit, suppliers, private Financial Desk, persistence and Smart Sync |
| Business mutations | Validation → inventoryCommit / RS.atomic → ledger and stock persistence → UI refresh |
| Credit Accounts | Customer records and credit ledger; collection settles receivables without deducting stock again |
| Financial Desk | PIN-gated private vault, owner confirmation and bank reconciliation; not shared as public business state |
| Smart Sync | Sanitized checkpoint, verified event origins, enrollment and accounted-event filtering |
| js/pwa.js, sw.js, manifest.json | Existing PWA registration, installation and static offline cache |
| js/android-sync-files.js | Existing native bridge interface; browser tests mock the bridge |
| _headers, _redirects, icons | Existing static Pages configuration and application icons |
| tests | Pinned Playwright/ESLint development dependencies; no runtime dependency |
| tools/package.py | Python standard-library ZIP creation, exact member verification and SHA-256 manifest |

All twelve non-HTML runtime files remain byte-identical to the 2.13.0 baseline. Application changes are confined to index.html. The source-boundary test allows only the documented functions/handlers and checks other script AST structure. This guards change scope; it does not replace behavioral tests.

## Credit editing extension

Sales Records Edit → CreditAccounts.editLine → commitSalesLedger → inventoryCommit/RS.atomic. Saved current-day copies update in the same transaction. Existing Smart Sync publishes sanitized correction history; bank allocations remain fixed.
