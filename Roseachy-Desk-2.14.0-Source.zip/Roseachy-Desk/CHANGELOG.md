# 2.14.0-credit-edit — 2026-10-20

- Expose Edit and guarded Remove for current-day credit-sale lines in Sales Records, reusing the existing editor.
- Preserve transaction/group IDs, original timestamps, upfront allocations and collection rows; append before/after correction history.
- Reconcile stock and receivables through the existing atomic ledger path; update saved copies of the current day in the same commit.
- Block excess-payment reductions, insufficient stock, exceeded credit limits, unsafe customer reassignment and stale editors.
- Transfer all lines of an unpaid purchase together when its customer changes.
- Remove the top-left Credit Accounts menu entry, Sales Records account-opening shortcuts and entry-form management shortcut. Preserve the right-side control unchanged.
- Include sanitized correction history in signed synchronization; omit private free-text notes from shared audit history.
- Compare saved-day business metadata independently of derived opening-batch layouts to avoid false conflicts after checkpoint reconstruction.
- Add 20 executable credit-edit checks and retain the existing regression suites.

Historical reports and baseline ZIPs remain under audit/baseline. No CSS or non-HTML runtime asset changes were made.
