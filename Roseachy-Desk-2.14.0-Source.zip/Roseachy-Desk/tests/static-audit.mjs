import { ESLint } from "eslint";
import globals from "globals";
import { fileURLToPath } from "node:url";
import fs from "node:fs/promises";
const root =
  process.env.ROSEACHY_APP_ROOT ||
  fileURLToPath(new URL("../", import.meta.url));
const resultsDir =
  process.env.ROSEACHY_RESULTS_DIR ||
  fileURLToPath(new URL("../.test-results/", import.meta.url));
await fs.mkdir(resultsDir, { recursive: true });
const html = await fs.readFile(root + "/index.html", "utf8");
const script = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)]
  .map((x) => x[1])
  .join("\n");
const eslint = new ESLint({
  overrideConfigFile: true,
  overrideConfig: {
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: "script",
      globals: {
        ...globals.browser,
        ...globals.serviceworker,
        RoseachyStore: "readonly",
        RoseachyFiles: "readonly",
        RoseachyCheckBackupFile: "readonly",
        AndroidSyncFileBridge: "readonly",
        RoseachyAndroid: "readonly",
        pdfjsLib: "readonly",
        module: "readonly",
      },
    },
    rules: {
      "no-undef": "error",
      "no-dupe-keys": "error",
      "no-unreachable": "error",
      "no-unused-vars": ["warn", { args: "none", caughtErrors: "none" }],
    },
  },
});
const results = [];
for (const [name, code] of [
  ["index.html inline scripts", script],
  ["sw.js", await fs.readFile(root + "/sw.js", "utf8")],
  ["js/pwa.js", await fs.readFile(root + "/js/pwa.js", "utf8")],
  ["js/android-sync-files.js", await fs.readFile(root + "/js/android-sync-files.js", "utf8")],
]) {
  const [result] = await eslint.lintText(code, { filePath: "app.js" });
  results.push({ name, ...result });
}
const messages = results.flatMap(r => r.messages.map(m => ({file:r.name, ...m})));
await fs.writeFile(
  resultsDir + "/static-findings.json",
  JSON.stringify(messages, null, 2),
);
console.log(
  messages
    .map(
      (x) => `${x.severity === 2 ? "ERROR" : "WARN"} ${x.file}:${x.line}: ${x.message}`,
    )
    .join("\n"),
);

process.exitCode = results.some(r => r.errorCount) ? 1 : 0;
