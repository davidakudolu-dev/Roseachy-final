import { browser, device, seed, root, resultsDir } from "./harness.mjs";
import fs from "node:fs/promises";
const results = [];
const a = await device(),
  b = await device();
const check = async (name, fn) => {
  try {
    const detail = await fn();
    results.push({ name, status: "passed", detail });
    console.log("PASS", name, detail ?? "");
  } catch (e) {
    results.push({ name, status: "failed", error: e.message });
    console.log("FAIL", name, e.message);
    throw e;
  }
};
function equal(x, y) {
  if (JSON.stringify(x) !== JSON.stringify(y))
    throw Error(`Expected ${JSON.stringify(y)}, got ${JSON.stringify(x)}`);
}
try {
  await seed(a.page);
  await seed(b.page);
  const offer = async (p) =>
    p.evaluate(async () => {
      const a = auditTest,
        b = await a.roseachySafeBackup();
      await a.SmartSync.verifyRecovery(b);
      return a.SmartSync.offer();
    });
  let oa, ob, cp;
  await check(
    "G establish verified common baseline through signed pairing",
    async () => {
      oa = await offer(a.page);
      ob = await offer(b.page);
      for (const [d, o] of [
        [a, ob],
        [b, oa],
      ])
        await d.page.evaluate(async (o) => {
          await auditTest.SyncPrivacy.trust(
            o.payload.sender.deviceId,
            o.payload.sender.publicKey,
            true,
          );
        }, o);
      cp = await a.page.evaluate(async (o) => {
        const s = auditTest.SmartSync,
          remote = await s.unprotect(o),
          choices = {
            sameBusiness: true,
            approvedBy: "Audit Fixture",
            snapshotScope: true,
            maps: { products: {}, transactions: {} },
            records: {},
            stock: {},
            accounts: {},
          };
        const plan = s.initialPlan(remote, choices);
        if (plan.conflicts.length) throw Error(JSON.stringify(plan.conflicts));
        return s.createCheckpoint(remote, choices);
      }, ob);
      for (const d of [a, b])
        await d.page.evaluate(
          (cp) =>
            auditTest.SmartSync.acceptCheckpoint(cp, {
              sameBusiness: true,
              approvedBy: "Audit Fixture",
            }),
          cp,
        );
      for (const [sender, receiver] of [
        [a, b],
        [b, a],
      ]) {
        const ack = await sender.page.evaluate(() =>
          auditTest.SmartSync.acknowledgement(),
        );
        await receiver.page.evaluate(
          async (ack) =>
            auditTest.SmartSync.acceptAcknowledgement(
              await auditTest.SmartSync.unprotect(ack),
            ),
          ack,
        );
      }
      equal(await a.page.evaluate(() => auditTest.getStock()[0].qty), 100);
      equal(await b.page.evaluate(() => auditTest.getStock()[0].qty), 100);
    },
  );
  await check(
    "G concurrent sale -10 and purchase +25 converge to 115 units",
    async () => {
      await a.page.evaluate(async () => {
        const a = auditTest;
        const ok = await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            {
              id: "device-a-sale",
              type: "sale_cash",
              productId: "fixture-product",
              amount: 10000,
              unitPrice: 1000,
              qty: 10,
              costSnapshot: 500,
              ts: new Date().toISOString(),
            },
          ]);
          if (err) throw Error(err);
          return true;
        }, "Sales Desk");
        if (ok !== true) throw Error("Sale failed");
      });
      await b.page.evaluate(async () => {
        const a = auditTest;
        const ok = await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            {
              id: "device-b-purchase",
              type: "purchase_cash",
              productId: "fixture-product",
              amount: 12500,
              unitPrice: 500,
              qty: 25,
              costSnapshot: 500,
              paymentFunding: "external",
              ts: new Date().toISOString(),
            },
          ]);
          if (err) throw Error(err);
          return true;
        }, "Market Desk");
        if (ok !== true) throw Error("Purchase failed");
      });
      for (const [sender, receiver] of [
        [a, b],
        [b, a],
      ]) {
        const pkg = await sender.page.evaluate(() =>
          auditTest.SmartSync.updates(),
        );
        await receiver.page.evaluate(async (pkg) => {
          const s = auditTest.SmartSync,
            p = await s.unprotect(pkg),
            plan = await s.planUpdates(p);
          if (plan.conflicts.length)
            throw Error(JSON.stringify(plan.conflicts));
          return s.merge(p);
        }, pkg);
      }
      for (const d of [a, b])
        equal(
          await d.page.evaluate(() => [
            auditTest.getStock()[0].qty,
            auditTest.getTx().length,
            auditTest.calc().sales,
            auditTest.calc().expectedCash,
          ]),
          [115, 2, 10000, 110000],
        );
    },
  );
  await check(
    "H repeated signed sync import produces no new effects",
    async () => {
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      for (let i = 0; i < 3; i++)
        await b.page.evaluate(async (pkg) => {
          const s = auditTest.SmartSync;
          return s.merge(await s.unprotect(pkg));
        }, pkg);
      equal(
        await b.page.evaluate(() => [
          auditTest.getStock()[0].qty,
          auditTest.getTx().length,
          auditTest.calc().sales,
          auditTest.calc().expectedCash,
        ]),
        [115, 2, 10000, 110000],
      );
    },
  );
  await check(
    "Sync credit customer, charge and partial repayment remain linked",
    async () => {
      const id = await a.page.evaluate(async () => {
        const a = auditTest,
          id = await a.CreditAccounts.create({
            name: "Sync Fixture",
            creditLimit: 30000,
          });
        await a.CreditAccounts.purchase({
          customerId: id,
          lines: [{ productId: "fixture-product", qty: 15 }],
          id: "sync-credit-sale",
        });
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 6000,
          id: "sync-credit-payment",
        });
        return id;
      });
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      await b.page.evaluate(async (pkg) => {
        const s = auditTest.SmartSync;
        await s.merge(await s.unprotect(pkg));
        await s.merge(await s.unprotect(pkg));
      }, pkg);
      for (const d of [a, b])
        equal(
          await d.page.evaluate(
            (id) => [
              auditTest.getStock()[0].qty,
              auditTest.CreditAccounts.balance(id),
              auditTest.calc().sales,
              auditTest.calc().closingDebt,
              auditTest.calc().expectedCash,
            ],
            id,
          ),
          [100, 9000, 25000, 0, 116000],
        );
    },
  );
  await check(
    "Sync signature rejects altered data without changing records",
    async () => {
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      pkg.payload.events[0].timestamp = "2000-01-01";
      equal(
        await b.page.evaluate(async (pkg) => {
          try {
            await auditTest.SmartSync.unprotect(pkg);
          } catch (e) {
            return [e.message, auditTest.getStock()[0].qty];
          }
        }, pkg),
        ["File authentication failed.", 100],
      );
    },
  );
  await check(
    "K backup restore preserves sync identity boundaries and replay safety",
    async () => {
      const backup = await b.page.evaluate(() =>
        auditTest.roseachySafeBackup(),
      );
      equal(
        await b.page.evaluate(async (backup) => {
          const a = auditTest;
          await a.inventoryCommit(() => {
            a.applyBackupData(backup);
            return true;
          }, "Backup restore");
          return [
            (await RoseachyStore.verify()).ok,
            a.getStock()[0].qty,
            a.getTx().length,
          ];
        }, backup),
        [true, 100, 4],
      );
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      await b.page.evaluate(async (pkg) => {
        const s = auditTest.SmartSync;
        return s.merge(await s.unprotect(pkg));
      }, pkg);
      equal(
        await b.page.evaluate(() => [
          auditTest.getStock()[0].qty,
          auditTest.getTx().length,
        ]),
        [100, 4],
      );
    },
  );
  await check(
    "I remote bank sale is held for owner approval and posts once after reimport",
    async () => {
      await a.page.evaluate(async () => {
        const a = auditTest;
        a.switchDesk("financial");
        for (const id of ["finSetupPassword", "finSetupPassword2"])
          document.getElementById(id).value = "1234";
        document.getElementById("finAnchorInput").value = "100000";
        document.getElementById("finAnchorMode").value = "day";
        await a.finSetup();
      });
      await b.page.evaluate(async () => {
        const a = auditTest;
        const ok = await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            ...a.getTx(),
            {
              id: "remote-bank-sale",
              type: "sale_transfer",
              productId: "fixture-product",
              qty: 1,
              amount: 1000,
              unitPrice: 1000,
              costSnapshot: 500,
              ts: new Date().toISOString(),
            },
          ]);
          if (err) throw Error(err);
          return true;
        }, "Sales Desk");
        if (ok !== true) throw Error("Sale did not save");
      });
      const pkg = await b.page.evaluate(() => auditTest.SmartSync.updates());
      await a.page.evaluate(async (pkg) => {
        const s = auditTest.SmartSync;
        await s.merge(await s.unprotect(pkg));
      }, pkg);
      equal(
        await a.page.evaluate(() => [
          auditTest.finLedger().balanceK,
          auditTest.BankReconciliation.queue().some(
            (t) => t.id === "remote-bank-sale",
          ),
        ]),
        [10000000, true],
      );
      await a.page.evaluate(() =>
        auditTest.BankReconciliation.decide("remote-bank-sale", "confirm"),
      );
      await a.page.evaluate(async (pkg) => {
        const s = auditTest.SmartSync;
        await s.merge(await s.unprotect(pkg));
      }, pkg);
      equal(
        await a.page.evaluate(() => [
          auditTest.finLedger().balanceK,
          auditTest.BankReconciliation.queue().some(
            (t) => t.id === "remote-bank-sale",
          ),
          auditTest.getStock()[0].qty,
        ]),
        [10100000, false, 99],
      );
      const receipt = await a.page.evaluate(() =>
        auditTest.SmartSync.updates(),
      );
      await b.page.evaluate(async (pkg) => {
        const s = auditTest.SmartSync;
        await s.merge(await s.unprotect(pkg));
      }, receipt);
      equal(
        await b.page.evaluate(() =>
          auditTest.BankReconciliation.settledTransaction(
            auditTest.getTx().find((t) => t.id === "remote-bank-sale"),
          ),
        ),
        true,
      );
    },
  );
  await check(
    "Shared sync files exclude private vault, PIN, and owner decision records",
    async () => {
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      const forbidden = new Set([
        "financeVault",
        "financeReview",
        "reconciliations",
        "reconciliationAudit",
        "pw",
        "private",
        "anchor",
      ]);
      const violations = [];
      const walk = (v) => {
        if (!v || typeof v !== "object") return;
        for (const [k, x] of Object.entries(v)) {
          if (forbidden.has(k)) violations.push(k);
          walk(x);
        }
      };
      walk(pkg);
      equal(violations, []);
    },
  );
  await check(
    "Concurrent overselling preserves both sales and identifies shortage",
    async () => {
      for (const [d, id] of [
        [a, "oversold-a"],
        [b, "oversold-b"],
      ])
        await d.page.evaluate(async (id) => {
          const a = auditTest;
          const ok = await a.inventoryCommit(() => {
            const err = a.commitSalesLedger([
              ...a.getTx(),
              {
                id,
                type: "sale_cash",
                productId: "fixture-product",
                qty: 80,
                amount: 80000,
                unitPrice: 1000,
                costSnapshot: 500,
                ts: new Date().toISOString(),
              },
            ]);
            if (err) throw Error(err);
            return true;
          }, "Sales Desk");
          if (ok !== true) throw Error("Local sale failed");
        }, id);
      for (const [sender, receiver] of [
        [a, b],
        [b, a],
      ]) {
        const pkg = await sender.page.evaluate(() =>
          auditTest.SmartSync.updates(),
        );
        await receiver.page.evaluate(async (pkg) => {
          const s = auditTest.SmartSync;
          await s.merge(await s.unprotect(pkg));
        }, pkg);
      }
      for (const d of [a, b])
        equal(
          await d.page.evaluate(() => [
            auditTest.getStock()[0].qty,
            auditTest.getStock()[0].syncDiscrepancy,
            auditTest.getTx().filter((t) => t.id.startsWith("oversold-"))
              .length,
          ]),
          [0, 61, 2],
        );
    },
  );
  await check(
    "Concurrent credit-limit edits require explicit conflict resolution",
    async () => {
      for (const [d, limit] of [
        [a, 35000],
        [b, 40000],
      ])
        await d.page.evaluate(
          (limit) =>
            auditTest.CreditAccounts.updateLimit(
              auditTest.CreditAccounts.customers()[0].id,
              limit,
            ),
          limit,
        );
      const pkg = await a.page.evaluate(() => auditTest.SmartSync.updates());
      equal(
        await b.page.evaluate(async (pkg) => {
          const a = auditTest,
            plan = await a.SmartSync.planUpdates(
              await a.SmartSync.unprotect(pkg),
            );
          return [
            plan.conflicts.some((c) => c.type === "record-conflict"),
            a.CreditAccounts.customers()[0].creditLimit,
          ];
        }, pkg),
        [true, 40000],
      );
    },
  );
  await check("No uncaught sync browser errors", () =>
    equal([...a.errors, ...b.errors], []),
  );
} catch (e) {
  console.log("Sync suite stopped at prerequisite failure:", e.message);
} finally {
  await fs.writeFile(
    resultsDir +
      "/" +
      (root.includes("/original") ? "baseline-sync" : "sync") +
      "-results.json",
    JSON.stringify(results, null, 2),
  );
  await browser.close();
}
process.exitCode = results.some((r) => r.status === "failed") ? 1 : 0;
