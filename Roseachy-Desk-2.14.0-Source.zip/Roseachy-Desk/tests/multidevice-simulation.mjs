import{device,browser,resultsDir}from'./harness.mjs';import fs from'node:fs/promises';import assert from'node:assert/strict';
const results=[];async function check(id,name,fn){try{const detail=await fn();results.push({id,name,status:'passed',detail});console.log('PASS',id,name)}catch(e){results.push({id,name,status:'failed',error:e.message});console.log('FAIL',id,name,e.message);throw e}finally{await fs.writeFile(resultsDir+'/multidevice-results.json',JSON.stringify(results,null,2))}}
const devices=await Promise.all([device(),device(),device(),device()]),[a,b,c,d]=devices.map(x=>x.page);const approval={sameBusiness:true,approvedBy:'Synthetic Audit Operator'};let product,customer,oldBackup,cp;
async function offer(p){return p.evaluate(async()=>{const a=auditTest,b=await a.roseachySafeBackup();await a.SmartSync.verifyRecovery(b);return a.SmartSync.offer()})}
async function trust(p,o){return p.evaluate(o=>auditTest.SyncPrivacy.trust(o.payload.sender.deviceId,o.payload.sender.publicKey,true),o)}
async function merge(p,pkg){return p.evaluate(async pkg=>{const s=auditTest.SmartSync,v=await s.unprotect(pkg),plan=await s.planUpdates(v);if(plan.conflicts.length)throw Error(JSON.stringify(plan.conflicts));return s.merge(v)},pkg)}
async function updates(p){return p.evaluate(()=>auditTest.SmartSync.updates())}
try{
await check('SYNC4-01','Two independent devices establish a verified checkpoint from a supported backup restore',async()=>{
 await a.evaluate(async()=>{const q=id=>document.getElementById(id),x=auditTest;q('business').value='Four Device Synthetic Shop';q('openingCash').value='100000';q('bulkStockText').value='Rice | Essentials | 500 | 1000 | 100';q('bulkStockBtn').click();q('bulkConfirmBtn').click();while(x.getView().inventoryBusy)await new Promise(r=>setTimeout(r,0));await x.ready()});product=await a.evaluate(()=>auditTest.getStock()[0].id);customer=await a.evaluate(()=>auditTest.CreditAccounts.create({name:'Shared Credit Customer',startingBalance:10000,startingConfirmed:true}));
 const initial=await a.evaluate(()=>auditTest.roseachySafeBackup());assert.equal(await b.evaluate(x=>auditTest.restoreFullBackup(x,{confirmRestore:false}),initial),true);
 const oa=await offer(a),ob=await offer(b);await trust(a,ob);await trust(b,oa);
 cp=await a.evaluate(async({ob,approval})=>{const s=auditTest.SmartSync,remote=await s.unprotect(ob),choices={...approval,snapshotScope:true,maps:{products:{},transactions:{}},records:{},stock:{},accounts:{}};const plan=s.initialPlan(remote,choices);if(plan.conflicts.length)throw Error(JSON.stringify(plan.conflicts));return s.createCheckpoint(remote,choices)},{ob,approval});
 for(const p of [a,b])await p.evaluate(({cp,approval})=>auditTest.SmartSync.acceptCheckpoint(cp,approval),{cp,approval});
 for(const [sender,receiver]of[[a,b],[b,a]]){const ack=await sender.evaluate(()=>auditTest.SmartSync.acknowledgement());await receiver.evaluate(async ack=>auditTest.SmartSync.acceptAcknowledgement(await auditTest.SmartSync.unprotect(ack)),ack)}
 oldBackup=await a.evaluate(()=>auditTest.roseachySafeBackup());return {members:2,stock:100};
});
await check('SYNC4-02','Third and fourth restored devices require explicit enrollment and retain distinct identities',async()=>{
 const active=[a,b];for(const child of[c,d]){assert.equal(await child.evaluate(x=>auditTest.restoreFullBackup(x,{confirmRestore:false}),oldBackup),true);assert.equal(await child.evaluate(()=>auditTest.SmartSync.status().recoveredDevice),true);const o=await offer(child);for(const p of active)await trust(p,o);const ownerOffer=await offer(a);await trust(child,ownerOffer);cp=await a.evaluate(async({o,approval})=>auditTest.SmartSync.join(await auditTest.SmartSync.unprotect(o),approval),{o,approval});active.push(child);for(const p of active){await p.evaluate(async cp=>{for(const [id,key]of Object.entries(cp.keys))await auditTest.SyncPrivacy.trust(id,key,true)},cp);await p.evaluate(({cp,approval})=>auditTest.SmartSync.acceptJoin(cp,approval),{cp,approval})}}
 for(const sender of[a,b,c,d]){const ack=await sender.evaluate(()=>auditTest.SmartSync.acknowledgement());for(const receiver of[a,b,c,d])if(receiver!==sender)await receiver.evaluate(async ack=>auditTest.SmartSync.acceptAcknowledgement(await auditTest.SmartSync.unprotect(ack)),ack)}
 assert.equal(new Set(await Promise.all([a,b,c,d].map(p=>p.evaluate(()=>auditTest.SmartSync.identity().deviceId)))).size,4);return {members:4};
});
await check('SYNC4-03','17 independent offline sales and a 50-unit receipt reconcile 100 − 17 + 50 = 133',async()=>{
 for(const [p,count,label]of[[a,10,'A'],[b,7,'B']])await p.evaluate(async({product,count,label})=>{const x=auditTest;for(let i=0;i<count;i++){const ok=await x.inventoryCommit(()=>{const err=x.commitSalesLedger([...x.getTx(),{id:label+'-sale-'+i,type:'sale_cash',productId:product,productName:'Rice',qty:1,amount:1000,unitPrice:1000,costSnapshot:500,ts:new Date().toISOString()}]);if(err)throw Error(err);return true},'Sales Desk');if(ok!==true)throw Error('Sale failed')}},{product,count,label});
 await c.evaluate(async product=>{const x=auditTest;const ok=await x.inventoryCommit(()=>{const err=x.commitSalesLedger([...x.getTx(),{id:'C-purchase',type:'purchase_cash',productId:product,productName:'Rice',qty:50,amount:25000,unitPrice:500,costSnapshot:500,paymentFunding:'external',ts:new Date().toISOString()}]);if(err)throw Error(err);return true},'Market Desk');if(ok!==true)throw Error('Purchase failed')},product);
 await d.evaluate(id=>auditTest.CreditAccounts.pay({customerId:id,amount:1000,id:'D-collection'}),customer);
 const pkgs=await Promise.all([a,b,c,d].map(updates));for(const [i,p]of[a,b,c,d].entries()){for(const index of (i%2?[3,2,1,0]:[0,1,2,3]))if(index!==i)await merge(p,pkgs[index])}
 const states=await Promise.all([a,b,c,d].map(p=>p.evaluate(id=>({qty:auditTest.getStock()[0].qty,ids:auditTest.getTx().map(t=>t.id).sort(),sales:auditTest.calc().sales,balance:auditTest.CreditAccounts.balance(id)}),customer)));for(const state of states){assert.equal(state.qty,133);assert.equal(state.ids.length,19);assert.equal(state.sales,17000);assert.equal(state.balance,9000);assert.deepEqual(state,states[0])}return {stock:133,uniqueTransactions:19,sales:17000,receivable:9000,orders:2};
});
await check('SYNC4-04','Three repeated imports leave the complete shared business projection unchanged',async()=>{
 const snapshot=p=>p.evaluate(()=>({stock:auditTest.getStock(),tx:auditTest.getTx(),customers:auditTest.CreditAccounts.customers(),market:auditTest.getMarketState(),totals:auditTest.calc()}));
 const before=await snapshot(b),pkg=await updates(a);for(let i=0;i<3;i++)await merge(b,pkg);assert.deepEqual(await snapshot(b),before);return {reimports:3};
});
await check('SYNC4-05','Restoring an older checkpoint cannot silently emit ordinary updates or erase current peers',async()=>{
 assert.equal(await d.evaluate(x=>auditTest.restoreFullBackup(x,{confirmRestore:false}),oldBackup),true);let rejected=false;try{await updates(d)}catch(e){rejected=/recovered|join|enroll|checkpoint|Reconnect|connect/i.test(e.message)}assert.equal(rejected,true);assert.equal(await a.evaluate(()=>auditTest.getStock()[0].qty),133);return {olderDeviceBlocked:true,currentStock:133};
});
await check('SYNC4-06','Tampered signatures do not mutate any business data',async()=>{
 const pkg=await updates(a),before=await b.evaluate(()=>JSON.stringify([auditTest.getStock(),auditTest.getTx()]));pkg.payload.events[0].timestamp='1999-01-01';let rejected=false;try{await merge(b,pkg)}catch(e){rejected=/authentication|signature/i.test(e.message)}assert.equal(rejected,true);assert.equal(await b.evaluate(()=>JSON.stringify([auditTest.getStock(),auditTest.getTx()])),before);return {rejected:true};
});
await check('SYNC4-07','No uncaught errors in four-device simulation',()=>assert.deepEqual(devices.flatMap(x=>x.errors),[]));
}catch{}finally{await browser.close();process.exitCode=results.some(x=>x.status==='failed')?1:0}
