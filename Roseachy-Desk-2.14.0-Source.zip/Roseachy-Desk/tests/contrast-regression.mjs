import {device,browser,resultsDir} from './harness.mjs';
import {contrastSamples} from './theme-inspect.mjs';
import fs from 'node:fs/promises';
const {page:p}=await device();let all=[];
await p.evaluate(async()=>{auditTest.switchDesk('financial');document.querySelector('#finSetupPassword').value='1234';document.querySelector('#finSetupPassword2').value='1234';document.querySelector('#finAnchorInput').value='100000';document.querySelector('#finAnchorMode').value='day';await auditTest.finSetup();auditTest.switchDesk('sales')});
for(const theme of ['cobalt','ember','pearl','cyanflux','lunarglass','coralbank','monomint','acidledger','tealagenda','violetwallet'])for(const colorMode of ['light','dark'])for(const desk of ['sales','stock','market','financial','financial-unlocked','settings','credit','sync']){
 await p.evaluate(({theme,colorMode,desk})=>{document.querySelectorAll('.marketOverlay,.dupOverlay').forEach(e=>e.classList.add('hidden'));auditTest.switchDesk(['credit','sync','stock'].includes(desk)?'sales':desk==='financial-unlocked'?'financial':desk);if(desk==='stock')auditTest.setTab('Stock');if(desk==='sales')auditTest.setTab('Tx');auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode});if(desk==='sync')auditTest.SmartSync.open();},{theme,colorMode,desk});
 if(desk==='financial-unlocked')await p.evaluate(async()=>{document.querySelector('#finUnlockPass').value='1234';await auditTest.finUnlock()});
 if(desk==='credit'){await p.locator('#creditMenuBtn').click();await p.locator('#creditMenuEntry').click();}
 await p.waitForTimeout(350);
 const selected=await p.evaluate(()=>{const found=[];for(const e of document.querySelectorAll('body *')){if(e.matches(':disabled')||e.closest('[disabled]')||['SCRIPT','STYLE','OPTION'].includes(e.tagName)||!e.getClientRects().length||getComputedStyle(e).visibility==='hidden')continue;const text=[...e.childNodes].filter(x=>x.nodeType===3).map(x=>x.textContent.trim()).join('').trim();if(!text)continue;e.dataset.contrastProbe=found.length;found.push({selector:'[data-contrast-probe="'+found.length+'"]',text:text.slice(0,70),id:e.id,className:e.className})}return found});
 const sampled=await p.evaluate(contrastSamples,selected.map(x=>x.selector));const bad=sampled.map((x,i)=>({...selected[i],...x})).filter(x=>!x.missing&&x.ratio<4.5);if(bad.length)all.push({theme,colorMode,desk,bad});
 await p.evaluate(()=>document.querySelectorAll('[data-contrast-probe]').forEach(e=>delete e.dataset.contrastProbe));
}
await fs.writeFile(resultsDir+'/contrast-findings.json',JSON.stringify(all,null,2));
const result={name:'Visible text on eight screen states meets 4.5:1 after each reference theme settles',status:all.length?'failed':'passed',detail:{themeModeScreenChecks:160,findings:all.length}};
await fs.writeFile(resultsDir+'/contrast-results.json',JSON.stringify([result],null,2)+'\n');console.log(result.status.toUpperCase(),result.name,all.length?JSON.stringify(all).slice(0,3500):'');await browser.close();process.exitCode=all.length?1:0;
