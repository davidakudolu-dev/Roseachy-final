import { browser, device, seed, root, resultsDir } from "./harness.mjs";
import fs from "node:fs/promises";
const results = [];
async function check(name, fn) {
  try {
    const detail = await fn();
    results.push({ name, status: "passed", detail });
    console.log("PASS", name, detail ?? "");
  } catch (e) {
    results.push({ name, status: "failed", error: e.message });
    console.log("FAIL", name, e.message);
  }
}
function equal(actual, expected) {
  if (JSON.stringify(actual) !== JSON.stringify(expected))
    throw Error(
      `Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
    );
}
const d = await device();
const p = d.page;
await seed(p);
await check("A cash sale: ledger, stock and cash once", async () =>
  equal(
    await p.evaluate(async () => {
      const a = auditTest;
      await a.inventoryCommit(() => {
        const err = a.commitSalesLedger([
          {
            id: "cash-sale",
            type: "sale_cash",
            productId: "fixture-product",
            productName: "Fixture Tablets 500mg",
            amount: 5000,
            unitPrice: 1000,
            qty: 5,
            costSnapshot: 500,
            ts: new Date().toISOString(),
          },
        ]);
        if (err) throw Error(err);
        return true;
      }, "Sales Desk");
      return [a.getStock()[0].qty, a.calc().sales, a.calc().expectedCash];
    }),
    [95, 5000, 105000],
  ),
);
await check(
  "B transfer sale: cash unchanged, bank movement recorded",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            ...a.getTx(),
            {
              id: "transfer-sale",
              type: "sale_transfer",
              productId: "fixture-product",
              amount: 10000,
              unitPrice: 1000,
              qty: 10,
              costSnapshot: 500,
              ts: new Date().toISOString(),
            },
          ]);
          if (err) throw Error(err);
          return true;
        }, "Sales Desk");
        return [
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().expectedBank,
        ];
      }),
      [85, 105000, 10000],
    ),
);
let customer;
await check(
  "D create account, credit sale and Opening Debts separation",
  async () => {
    customer = await p.evaluate(() =>
      auditTest.CreditAccounts.create({
        name: "Fixture Customer",
        creditLimit: 20000,
      }),
    );
    equal(
      await p.evaluate(async (id) => {
        const a = auditTest;
        await a.CreditAccounts.purchase({
          customerId: id,
          lines: [{ productId: "fixture-product", qty: 15 }],
          id: "credit-sale",
        });
        return [
          a.CreditAccounts.balance(id),
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().closingDebt,
          a.calc().sales,
        ];
      }, customer),
      [15000, 70, 105000, 0, 30000],
    );
  },
);
await check(
  "E partial credit collection, no second sale or stock movement",
  async () =>
    equal(
      await p.evaluate(async (id) => {
        const a = auditTest;
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 6000,
          id: "partial",
        });
        return [
          a.CreditAccounts.balance(id),
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().sales,
        ];
      }, customer),
      [9000, 70, 111000, 30000],
    ),
);
await check(
  "F final credit settlement and duplicate payment replay",
  async () =>
    equal(
      await p.evaluate(async (id) => {
        const a = auditTest;
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 9000,
          id: "final",
        });
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 9000,
          id: "final",
        });
        return [
          a.CreditAccounts.balance(id),
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.getTx().length,
          a.calc().sales,
        ];
      }, customer),
      [0, 70, 120000, 5, 30000],
    ),
);
await check("Credit limit rejects excess debt without mutation", async () =>
  equal(
    await p.evaluate(async (id) => {
      const a = auditTest;
      try {
        await a.CreditAccounts.purchase({
          customerId: id,
          lines: [{ productId: "fixture-product", qty: 21 }],
          id: "too-large",
        });
      } catch (e) {
        return [
          /limit exceeded/.test(e.message),
          a.getStock()[0].qty,
          a.getTx().length,
        ];
      }
      return false;
    }, customer),
    [true, 70, 5],
  ),
);
await check("Credit purchase idempotency", async () =>
  equal(
    await p.evaluate(async (id) => {
      const a = auditTest;
      await a.CreditAccounts.purchase({
        customerId: id,
        lines: [{ productId: "fixture-product", qty: 15 }],
        id: "credit-sale",
      });
      return [
        a.getStock()[0].qty,
        a.CreditAccounts.balance(id),
        a.getTx().length,
      ];
    }, customer),
    [70, 0, 5],
  ),
);
await check("J void payment and sale group restores exact effects", async () =>
  equal(
    await p.evaluate(async (id) => {
      const a = auditTest;
      await a.CreditAccounts.voidGroup("final");
      await a.CreditAccounts.voidGroup("partial");
      await a.CreditAccounts.voidGroup("credit-sale");
      return [
        a.CreditAccounts.balance(id),
        a.getStock()[0].qty,
        a.calc().expectedCash,
        a.calc().sales,
      ];
    }, customer),
    [0, 85, 105000, 15000],
  ),
);
await check(
  "Credit sale cannot be voided while later repayments remain",
  async () => {
    equal(
      await p.evaluate(async (id) => {
        const a = auditTest;
        await a.CreditAccounts.purchase({
          customerId: id,
          lines: [{ productId: "fixture-product", qty: 15 }],
          id: "credit-sale-2",
        });
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 6000,
          id: "pay-2",
        });
        try {
          await a.CreditAccounts.voidGroup("credit-sale-2");
        } catch (e) {
          return [
            a.CreditAccounts.balance(id),
            a.getStock()[0].qty,
            a.getTx().length,
          ];
        }
        return false;
      }, customer),
      [9000, 70, 4],
    );
  },
);
await check(
  "Historical sale prices remain fixed after price changes",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.inventoryCommit(() => {
          const stock = structuredClone(a.getStock());
          stock[0].price = 2000;
          a.setStock(stock);
          return true;
        });
        a.render();
        return [a.getTx()[0].amount, a.calc().sales, a.getStock()[0].qty];
      }),
      [5000, 30000, 70],
    ),
);
await check(
  "Inventory replay is idempotent across repeated renders",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        for (let i = 0; i < 3; i++) {
          await a.inventoryCommit(() => a.rebuildStockFromOpening());
          a.render();
        }
        return [a.getStock()[0].qty, a.calc().sales];
      }),
      [70, 30000],
    ),
);
await check("Atomic storage abort preserves persisted stock", async () =>
  equal(
    await p.evaluate(async () => {
      const a = auditTest;
      try {
        await RoseachyStore.atomic(() => {
          const stock = structuredClone(a.getStock());
          stock[0].qty = 1;
          stock[0].batches[0].qty = 1;
          a.setStock(stock);
          throw Error("Injected failure");
        });
      } catch {}
      return [a.getStock()[0].qty, (await RoseachyStore.verify()).ok];
    }),
    [70, true],
  ),
);
await check(
  "Partial split receipts classified by actual payment amounts",
  async () =>
    equal(
      await p.evaluate(() => {
        const c = auditTest.calc(
          [
            {
              type: "sale_split",
              amount: 10000,
              splitCash: 4000,
              splitBank: 3000,
              splitCredit: 3000,
            },
          ],
          { openingCash: 0, openingDebt: 0 },
        );
        return [
          c.cashSales,
          c.nonCashSales,
          c.sales,
          c.expectedCash,
          c.expectedBank,
          c.closingDebt,
        ];
      }),
      [4000, 6000, 10000, 4000, 3000, 3000],
    ),
);
await check("Pack quantity authoritative total: 20 units / 12", async () =>
  equal(await p.evaluate(() => auditTest.packBreakdown(20, 12)), {
    packs: 1,
    loose: 8,
  }),
);
await check("Storage retention removes only expired audit detail", async () =>
  equal(
    await p.evaluate(async () => {
      const rs = RoseachyStore,
        key = "roseachy_inventory_audit_v1";
      await rs.atomic(() =>
        rs.setCollection(key, [
          ...rs.getObject(key),
          { id: "expired-fixture", timestamp: "2020-01-01T00:00:00.000Z" },
        ]),
      );
      try {
        await rs.atomic(() =>
          rs.setCollection(
            key,
            rs.getObject(key).filter((x) => x.id !== "expired-fixture"),
          ),
        );
      } catch (e) {
        throw Error(e.message);
      }
      return rs.getObject(key).some((x) => x.id === "expired-fixture");
    }),
    false,
  ),
);
await check("Active audit history cannot be deleted", async () =>
  equal(
    await p.evaluate(async () => {
      try {
        await RoseachyStore.atomic(() =>
          RoseachyStore.setCollection("roseachy_inventory_audit_v1", []),
        );
      } catch (e) {
        return e.message;
      }
      return false;
    }),
    "Recent adjustment history cannot be removed.",
  ),
);
await check(
  "I protected bank unchanged before confirmation; applies once",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.finance();
        const before = a.finLedger().balanceK;
        await a.BankReconciliation.decide("transfer-sale", "confirm");
        const after = a.finLedger().balanceK;
        await a.BankReconciliation.decide("transfer-sale", "confirm");
        return [before, after, a.finLedger().balanceK];
      }),
      [10000000, 11000000, 11000000],
    ),
);
await check(
  "Confirmed standalone bank supplier payment settles liability",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.inventoryCommit(() => {
          a.getTx().push({
            id: "supplier-bank-fixture",
            type: "supplier_pay_bank",
            amount: 1000,
            supplierPaymentId: "supplier-payment-fixture",
            qty: 0,
            unitPrice: 0,
            ts: new Date().toISOString(),
            paymentFunding: "business",
          });
          return true;
        }, "Market Desk");
        const t = a.getTx().find((t) => t.id === "supplier-bank-fixture");
        const pending = a.BankReconciliation.settledTransaction(t);
        await a.BankReconciliation.decide(t.id, "confirm");
        return [pending, a.BankReconciliation.settledTransaction(t)];
      }),
      [false, true],
    ),
);
await check("No uncaught application errors", () => equal(d.errors, []));
await fs.writeFile(
  resultsDir +
    "/" +
    (root.includes("/original") ? "baseline" : "regression") +
    "-results.json",
  JSON.stringify(results, null, 2),
);
await browser.close();
process.exitCode = results.some((r) => r.status === "failed") ? 1 : 0;
