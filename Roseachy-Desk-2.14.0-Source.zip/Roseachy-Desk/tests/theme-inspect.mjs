// Browser-side sampling includes actual gradient stops and inherited surfaces.
export function contrastSamples(selectors){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const c=canvas.getContext('2d',{willReadFrequently:true});
 const rgb=v=>{c.clearRect(0,0,1,1);c.fillStyle=v;c.fillRect(0,0,1,1);return [...c.getImageData(0,0,1,1).data].map((x,i)=>i===3?x/255:x)};
 const mix=(f,b)=>f.slice(0,3).map((v,i)=>v*f[3]+b[i]*(1-f[3]));
 const lum=x=>x.slice(0,3).map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);
 const cr=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 const colors=s=>[...s.matchAll(/#[\da-f]{3,8}\b|rgba?\([^)]*\)|color\([^)]*\)/gi)].map(x=>rgb(x[0]));
 const surfaces=e=>{if(!e)return [[255,255,255]];const s=getComputedStyle(e),base=rgb(s.backgroundColor);let under=base[3]===1?[base]:surfaces(e.parentElement).map(b=>[...mix(base,b),1]);const layers=[];let depth=0,start=0;for(let i=0;i<s.backgroundImage.length;i++){const ch=s.backgroundImage[i];if(ch==='(')depth++;if(ch===')')depth--;if(ch===','&&depth===0){layers.push(s.backgroundImage.slice(start,i));start=i+1}}layers.push(s.backgroundImage.slice(start));for(const layer of layers.reverse()){const stops=colors(layer);if(stops.length)under=stops.flatMap(f=>under.map(b=>[...mix(f,b),1]))}return under};
 return selectors.map(sel=>{const e=document.querySelector(sel);if(!e)return {selector:sel,missing:true};const s=getComputedStyle(e),fg=rgb(s.webkitTextFillColor==='currentcolor'?s.color:s.webkitTextFillColor);let bg=surfaces(e);if(e.matches('.hasInd > button.active')&&!e.closest('.marketViewTabs')){const indicator=e.parentElement.querySelector('.tabInd');if(indicator)bg=surfaces(indicator)}return {selector:sel,ratio:Math.min(...bg.map(b=>cr(fg,b))),foreground:s.webkitTextFillColor,background:s.backgroundColor,image:s.backgroundImage}});
}
