import { browser, device, seed, root, resultsDir } from "./harness.mjs";
import fs from "node:fs/promises";
const results = [];
const check = async (name, fn) => {
  try {
    const detail = await fn();
    results.push({ name, status: "passed", detail });
    console.log("PASS", name, detail ?? "");
  } catch (e) {
    results.push({ name, status: "failed", error: e.message });
    console.log("FAIL", name, e.message);
  }
};
function equal(x, y) {
  if (JSON.stringify(x) !== JSON.stringify(y))
    throw Error(`Expected ${JSON.stringify(y)}, got ${JSON.stringify(x)}`);
}
const d = await device({ mobile: true }),
  p = d.page;
await seed(p);
async function ready() {
  await p.waitForFunction(() => !auditTest.getView().inventoryBusy);
  await p.evaluate(() => auditTest.ready());
}
async function preparePurchase({
  paid = 30000,
  supplier = false,
  id = "market-cash",
  purchasePage = p,
} = {}) {
  await purchasePage.evaluate(
    async ({ paid, supplier, id }) => {
      const a = auditTest,
        m = a.getMarketState(),
        time = new Date().toISOString();
      if (supplier)
        m.suppliers.push({
          id: "fixture-supplier",
          name: "Fixture Supplier",
          phone: "",
          createdAt: time,
        });
      const purchase = {
        productId: "fixture-product",
        name: "Fixture Tablets 500mg",
        totalUnits: 20,
        packs: 1,
        loose: 8,
        unitsPerPack: 12,
        totalCost: 30000,
        cost: 1500,
        sell: 2000,
        priceMode: "manual",
        markupMode: "custom",
        markupPercent: 0,
        division: "pharmacy",
        payment: "purchase_cash",
        marketPurchaseId: id,
      };
      m.activeLists = [
        {
          id: "fixture-list-" + id,
          supplierId: supplier ? "fixture-supplier" : null,
          supplierNameDraft: "",
          amountPaid: paid,
          amountPaidExplicit: true,
          paymentMethod: "purchase_cash",
          paymentFunding: "business",
          paymentMethodExplicit: true,
          createdAt: time,
          updatedAt: time,
          items: [
            {
              id: "fixture-item-" + id,
              productId: "fixture-product",
              purchase,
            },
          ],
        },
      ];
      m.selectedActiveListId = m.activeLists[0].id;
      m.active = m.activeLists[0].items;
      await RoseachyStore.atomic(() => a.setMarketState(m));
      a.switchDesk("market");
      a.openMarketReview("active");
    },
    { paid, supplier, id },
  );
}
await check(
  "C Market cash purchase +20 units / -30000 cash / no revenue",
  async () => {
    await preparePurchase();
    await p.locator("#marketApplyAll").click();
    await ready();
    equal(
      await p.evaluate(() => {
        const a = auditTest;
        return [
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().sales,
          a.getMarketState().history.length,
          a.getMarketState().marketPurchases[0].total,
        ];
      }),
      [120, 70000, 0, 1, 30000],
    );
  },
);
await check(
  "Rapid repeated Market completion does not duplicate purchase",
  async () => {
    await p.evaluate(() => document.querySelector("#marketApplyAll").click());
    await ready();
    equal(
      await p.evaluate(() => [
        auditTest.getStock()[0].qty,
        auditTest.getTx().length,
        auditTest.getMarketState().history.length,
      ]),
      [120, 1, 1],
    );
  },
);
await check(
  "Partially paid supplier purchase records actual funds and payable separately",
  async () => {
    await preparePurchase({
      paid: 10000,
      supplier: true,
      id: "market-partial",
    });
    await p.locator("#marketApplyAll").click();
    await ready();
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          q = a.getMarketState().marketPurchases[0];
        return [
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().sales,
          a.calc().closingPayable,
          a.supplierPurchaseOutstanding(q),
          q.initialPaid,
        ];
      }),
      [140, 60000, 0, 20000, 20000, 10000],
    );
  },
);
await check(
  "Supplier cash payment reduces payable with no stock/revenue effect",
  async () => {
    await p.evaluate(() => {
      const a = auditTest;
      a.openSupplierPayment(a.getMarketState().marketPurchases[0].id);
    });
    await p.locator("#supplierPaymentAmount").fill("6000");
    await p.locator("#supplierPaymentSave").click();
    await ready();
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          q = a.getMarketState().marketPurchases[0];
        return [
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().sales,
          a.calc().closingPayable,
          a.supplierPurchaseOutstanding(q),
          q.payments.length,
        ];
      }),
      [140, 54000, 0, 14000, 14000, 1],
    );
  },
);
await p.evaluate(() => {
  document.querySelector("#supplierDetailOverlay").classList.add("hidden");
  auditTest.switchDesk("sales");
});
await check(
  "L mobile account Save responds once to a rapid double click",
  async () => {
    await p.evaluate(() => auditTest.CreditAccounts.open());
    await p.locator("#creditNew").click();
    await p.locator("#creditName").fill("Mobile Fixture");
    await p.locator("#creditLimit").fill("20000");
    await p.evaluate(() => {
      const b = document.querySelector("#creditConfirm");
      b.click();
      b.click();
    });
    await p.waitForSelector("#creditAddProducts");
    equal(
      await p.evaluate(
        () =>
          auditTest.CreditAccounts.customers().filter(
            (c) => c.name === "Mobile Fixture",
          ).length,
      ),
      1,
    );
  },
);
await check(
  "L product suggestion, quantity typing and credit purchase UI",
  async () => {
    await p.locator("#creditAddProducts").click();
    await p.locator("[data-product-search]").fill("Fixture");
    await p.locator("[data-credit-product]").first().click();
    await p.locator("[data-quantity]").fill("3");
    equal(await p.locator("[data-quantity]").inputValue(), "3");
    await p.locator("#creditConfirm").click();
    await p.waitForSelector("#creditRecordPayment");
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          c = a.CreditAccounts.customers().find(
            (c) => c.name === "Mobile Fixture",
          );
        return [
          a.CreditAccounts.balance(c.id),
          a.getStock()[0].qty,
          a.calc().sales,
        ];
      }),
      [6000, 137, 6000],
    );
  },
);
await check(
  "L mobile credit payment submission and persisted history",
  async () => {
    await p.locator("#creditRecordPayment").click();
    await p.locator("#creditPaymentAmount").fill("2000");
    await p.locator("#creditConfirm").click();
    await p.waitForSelector("#creditRecordPayment");
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          c = a.CreditAccounts.customers().find(
            (c) => c.name === "Mobile Fixture",
          );
        return [
          a.CreditAccounts.balance(c.id),
          a.getStock()[0].qty,
          a.calc().sales,
          a.calc().expectedCash,
          a.CreditAccounts.records().filter((t) => t.creditCustomerId === c.id)
            .length,
        ];
      }),
      [4000, 137, 6000, 56000, 2],
    );
    await p.locator("#creditClose").click();
  },
);
await check(
  "Stock pack fields do not rewrite the active loose-unit input",
  async () => {
    equal(
      await p.evaluate(() => {
        const q = (id) => document.getElementById(id);
        q("stockPackEnabled").checked = true;
        q("stockUnitsPerPack").value = "12";
        q("stockPacks").value = "0";
        q("stockLooseUnits").value = "24";
        auditTest.stockPackSync({ target: q("stockLooseUnits") });
        return [
          q("stockLooseUnits").value,
          q("stockQty").value,
          q("stockPackTotal").value,
        ];
      }),
      ["24", "24", "24"],
    );
  },
);
await check(
  "Failed IndexedDB writes roll back stock, ledger and sync events",
  async () => {
    equal(
      await p.evaluate(async () => {
        const a = auditTest,
          before = [
            a.getStock()[0].qty,
            a.getTx().length,
            a.SmartSync.backup().events.length,
          ];
        await RoseachyStore.whenSaved();
        const original = IDBDatabase.prototype.transaction;
        IDBDatabase.prototype.transaction = function (stores, mode, ...rest) {
          if (mode === "readwrite")
            throw new DOMException(
              "Injected storage failure",
              "QuotaExceededError",
            );
          return original.call(this, stores, mode, ...rest);
        };
        let result;
        try {
          result = await a.inventoryCommit(() => {
            const err = a.commitSalesLedger([
              ...a.getTx(),
              {
                id: "should-not-save",
                type: "sale_cash",
                productId: "fixture-product",
                qty: 1,
                unitPrice: 2000,
                amount: 2000,
                costSnapshot: 1500,
                ts: new Date().toISOString(),
              },
            ]);
            if (err) throw Error(err);
            return true;
          }, "Sales Desk");
        } finally {
          IDBDatabase.prototype.transaction = original;
        }
        return [
          result,
          JSON.stringify(before) ===
            JSON.stringify([
              a.getStock()[0].qty,
              a.getTx().length,
              a.SmartSync.backup().events.length,
            ]),
          (await RoseachyStore.verify()).ok,
        ];
      }),
      [false, true, true],
    );
  },
);
let backup;
await check(
  "K Full Backup export includes all domains, validates SHA-256",
  async () => {
    backup = await p.evaluate(() => auditTest.roseachySafeBackup());
    equal(
      await p.evaluate((b) => {
        auditTest.validateFullBackup(b);
        return [
          b.stock.length,
          b.creditCustomers.length,
          b.market.marketPurchases.length,
          b.draft.tx.length,
          !!b.integrity.hash,
        ];
      }, backup),
      [1, 1, 2, 6, true],
    );
  },
);
await check(
  "K Full Backup restore controller recovers stock and credit with safety copy",
  async () => {
    await p.evaluate(async () => {
      const a = auditTest;
      await a.CreditAccounts.pay({
        customerId: a.CreditAccounts.customers()[0].id,
        amount: 1000,
        id: "after-backup",
      });
    });
    const download = p.waitForEvent("download");
    const restored = await p.evaluate(
      (b) => auditTest.restoreFullBackup(b, { confirmRestore: false }),
      backup,
    );
    await (await download).saveAs(resultsDir + "/fixture-safety-backup.json");
    equal(restored, true);
    equal(
      await p.evaluate(() => [
        auditTest.getStock()[0].qty,
        auditTest.CreditAccounts.balance(
          auditTest.CreditAccounts.customers()[0].id,
        ),
        auditTest.getTx().length,
      ]),
      [137, 4000, 6],
    );
  },
);
await check("Malformed backup leaves records intact", async () => {
  const corrupt = structuredClone(backup);
  corrupt.stock[0].qty = -100;
  equal(
    await p.evaluate(async (b) => {
      const a = auditTest;
      const ok = await a.restoreFullBackup(b, { confirmRestore: false });
      return [
        ok,
        a.getStock()[0].qty,
        a.CreditAccounts.balance(a.CreditAccounts.customers()[0].id),
      ];
    }, corrupt),
    [false, 137, 4000],
  );
});
await check("Persisted records survive page reload", async () => {
  await p.reload();
  await p.waitForFunction(() => window.__roseachyFirstUsableMs !== undefined);
  equal(
    await p.evaluate(() => [
      auditTest.getStock()[0].qty,
      auditTest.getTx().length,
      auditTest.CreditAccounts.balance(
        auditTest.CreditAccounts.customers()[0].id,
      ),
    ]),
    [137, 6, 4000],
  );
});
await check(
  "Financial PIN setup, wrong PIN rejection, and correct unlock",
  async () => {
    await p.evaluate(async () => {
      const a = auditTest;
      a.switchDesk("financial");
      document.querySelector("#finSetupPassword").value = "1234";
      document.querySelector("#finSetupPassword2").value = "1234";
      document.querySelector("#finAnchorInput").value = "100000";
      document.querySelector("#finAnchorMode").value = "day";
      await a.finSetup();
      a.switchDesk("sales");
      await a.ready();
      a.switchDesk("financial");
      document.querySelector("#finUnlockPass").value = "9999";
      await a.finUnlock();
    });
    equal(await p.evaluate(() => auditTest.getFinance() === null), true);
    await p.evaluate(async () => {
      document.querySelector("#finUnlockPass").value = "1234";
      await auditTest.finUnlock();
    });
    equal(await p.evaluate(() => auditTest.finLedger().balanceK), 10000000);
  },
);
await check(
  "PIN-gated bank repayment awaits approval and posts only once",
  async () => {
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        const id = a.CreditAccounts.customers()[0].id;
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 1000,
          method: "transfer",
          id: "bank-credit-payment",
        });
        const before = a.finLedger().balanceK;
        await a.BankReconciliation.decide("bank-credit-payment", "confirm");
        await a.BankReconciliation.decide("bank-credit-payment", "confirm");
        return [
          before,
          a.finLedger().balanceK,
          a.CreditAccounts.balance(id),
          a.calc().sales,
          a.getStock()[0].qty,
        ];
      }),
      [10000000, 10100000, 3000, 6000, 137],
    );
  },
);
await check(
  "Bank reversal can be approved once and then leaves review queue",
  async () => {
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.CreditAccounts.voidGroup("bank-credit-payment");
        await a.BankReconciliation.decide("bank-credit-payment", "confirm");
        return [
          a.finLedger().balanceK,
          a.BankReconciliation.queue().filter(
            (t) => t.id === "bank-credit-payment",
          ).length,
        ];
      }),
      [10000000, 0],
    );
  },
);
await check("Leaving Financial Desk clears the unlocked session", async () => {
  await p.evaluate(() => auditTest.switchDesk("sales"));
  equal(await p.evaluate(() => auditTest.getFinance() === null), true);
});
await check("L repeated desk/tab navigation preserves records", async () => {
  await p.evaluate(() => {
    const a = auditTest;
    for (let i = 0; i < 3; i++) {
      for (const d of ["market", "settings", "sales"]) a.switchDesk(d);
      for (const t of ["Stock", "Report", "Analytics", "Notes", "Tx"])
        a.setTab(t);
    }
  });
  equal(
    await p.evaluate(() => [
      auditTest.getStock()[0].qty,
      auditTest.getTx().length,
    ]),
    [137, 6],
  );
});
await check("No uncaught workflow errors", () => equal(d.errors, []));
await d.close();
await check(
  "Legacy stock/localStorage migration preserves quantities and is repeatable",
  async () => {
    const legacy = {
      dsb_stock_v2: [
        {
          id: "legacy-product",
          name: "Legacy fixture",
          qty: 20,
          price: 500,
          costPrice: 300,
          packEnabled: true,
          unitsPerPack: 12,
        },
      ],
      dsb_saved_v2: [],
    };
    const x = await device({ legacy });
    equal(
      await x.page.evaluate(() => [
        auditTest.getStock()[0].qty,
        auditTest.getStock()[0].sealedPacks,
        auditTest.getStock()[0].looseUnits,
        RoseachyStore.status().mode,
        true,
      ]),
      [20, 1, 8, "indexeddb", true],
    );
    await x.page.reload();
    await x.page.waitForFunction(
      () => window.__roseachyFirstUsableMs !== undefined,
    );
    equal(await x.page.evaluate(() => auditTest.getStock()[0].qty), 20);
    await x.close();
  },
);
await check(
  "LocalStorage fallback atomic save and rollback preserve real records",
  async () => {
    const x = await device({ fallback: true });
    await seed(x.page);
    equal(
      await x.page.evaluate(async () => {
        const a = auditTest;
        const id = await a.CreditAccounts.create({ name: "Fallback Fixture" });
        await a.CreditAccounts.purchase({
          customerId: id,
          lines: [{ productId: "fixture-product", qty: 15 }],
          id: "fallback-sale",
        });
        await a.CreditAccounts.pay({
          customerId: id,
          amount: 6000,
          id: "fallback-pay",
        });
        return [
          RoseachyStore.status().mode,
          a.getStock()[0].qty,
          a.CreditAccounts.balance(id),
          (await RoseachyStore.verify()).ok,
        ];
      }),
      ["localstorage", 85, 9000, true],
    );
    await x.close();
  },
);
await check(
  "Market advance and supplier payment retain the same funding link",
  async () => {
    const x = await device();
    await seed(x.page);
    await x.page.evaluate(async () => {
      const s = auditTest.SmartSync;
      const id = await s.advance(30000, "Fixture advance");
      s.setMarketOptions({ advanceId: id });
    });
    await preparePurchase({
      paid: 10000,
      supplier: true,
      id: "advance-purchase",
      purchasePage: x.page,
    });
    await x.page.locator("#marketApplyAll").click();
    await x.page.waitForFunction(() => !auditTest.getView().inventoryBusy);
    equal(
      await x.page.evaluate(() => {
        const a = auditTest,
          m = a.getMarketState(),
          q = m.marketPurchases[0],
          t = a.getTx().find((t) => t.supplierPaymentId === q.initialPaymentId);
        return [
          a.calc().expectedCash,
          q.initialPaymentFunding,
          t.paymentFunding,
          q.marketAdvanceId === t.marketAdvanceId,
          a.SmartSync.advanceBalance(q.marketAdvanceId),
        ];
      }),
      [70000, "external", "external", true, 20000],
    );
    await x.close();
  },
);
await fs.writeFile(
  resultsDir +
    "/" +
    (root.includes("/original") ? "baseline-workflow" : "workflow") +
    "-results.json",
  JSON.stringify(results, null, 2),
);
await browser.close();
process.exitCode = results.some((x) => x.status === "failed") ? 1 : 0;
