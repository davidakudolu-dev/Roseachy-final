// Capture synthetic, empty-profile visual evidence; never accesses user records.
import {device,browser,root} from './harness.mjs';
import fs from 'node:fs/promises';
const {page:p}=await device();
const output=root+'/audit/screenshots';await fs.mkdir(output,{recursive:true});
async function choose(theme,colorMode='light'){
 await p.evaluate(()=>auditTest.switchDesk('settings'));
 await p.locator('[data-theme-choice="'+theme+'"]').click();
 await p.locator('[data-setting-buttons="colorMode"] [data-value="'+colorMode+'"]').click();
 await p.evaluate(()=>auditTest.ready());
}
async function capture(name,width=1280){
 await p.setViewportSize({width,height:900});await p.evaluate(()=>{document.activeElement?.blur();scrollTo(0,0)});
 await p.waitForTimeout(400);await p.screenshot({path:output+'/'+name+'.png',animations:'disabled'});
}
for(const theme of ['cyanflux','lunarglass','coralbank','monomint','acidledger','tealagenda','violetwallet']){
 await choose(theme);await p.evaluate(()=>auditTest.switchDesk('sales'));await capture(theme);await capture(theme+'-mobile',390);
}
await choose('lunarglass');await p.evaluate(()=>auditTest.switchDesk('market'));await capture('lunarglass-market');
await choose('violetwallet','dark');await capture('violetwallet-dark-settings');
await choose('coralbank');await p.evaluate(async()=>{auditTest.switchDesk('financial');document.querySelector('#finSetupPassword').value='1234';document.querySelector('#finSetupPassword2').value='1234';document.querySelector('#finAnchorInput').value='100000';document.querySelector('#finAnchorMode').value='day';await auditTest.finSetup()});await p.locator('#finSetupDone').click();await capture('coralbank-financial');
await browser.close();console.log('17 screenshots refreshed');
