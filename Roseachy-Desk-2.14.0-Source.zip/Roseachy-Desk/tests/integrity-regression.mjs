import { browser, device, seed, root, resultsDir } from "./harness.mjs";
import fs from "node:fs/promises";
const results = [];
const check = async (name, fn) => {
  try {
    const detail = await fn();
    results.push({ name, status: "passed", detail });
    console.log("PASS", name, detail ?? "");
  } catch (e) {
    results.push({ name, status: "failed", error: e.message });
    console.log("FAIL", name, e.message);
  }
};
function equal(x, y) {
  if (JSON.stringify(x) !== JSON.stringify(y))
    throw Error(`Expected ${JSON.stringify(y)}, got ${JSON.stringify(x)}`);
}
const d = await device(),
  p = d.page;
await seed(p);
await check(
  "POS cash service charge affects cash separately from electronic principal",
  async () =>
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          pos = a.posBuild("pos_withdrawal", 10000, 0, 100, "cash"),
          c = a.calc([{ type: "pos_withdrawal", amount: 10000, pos }], {
            openingCash: 0,
            posOpeningCash: 20000,
            posOpeningElectronic: 5000,
            openingDebt: 0,
          });
        return [
          c.pos.expectedCash,
          c.pos.expectedElectronic,
          c.pos.income,
          c.sales,
        ];
      }),
      [10100, 15000, 100, 0],
    ),
);
await check(
  "POS electronic service charge affects the electronic balance",
  async () =>
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          pos = a.posBuild("pos_withdrawal", 10000, 0, 100, "elec"),
          c = a.calc([{ type: "pos_withdrawal", amount: 10000, pos }], {
            openingCash: 0,
            posOpeningCash: 20000,
            posOpeningElectronic: 5000,
            openingDebt: 0,
          });
        return [
          c.pos.expectedCash,
          c.pos.expectedElectronic,
          c.pos.income,
          c.sales,
        ];
      }),
      [10000, 15100, 100, 0],
    ),
);
await check("Internal retail/POS transfer conserves combined funds", async () =>
  equal(
    await p.evaluate(() => {
      const c = auditTest.calc(
        [{ type: "cash_transfer", amount: 3000, from: "retail", to: "pos" }],
        {
          openingCash: 10000,
          posOpeningCash: 0,
          posOpeningElectronic: 0,
          openingDebt: 0,
        },
      );
      return [c.expectedCash, c.pos.expectedCash, c.storeCash, c.sales];
    }),
    [7000, 3000, 10000, 0],
  ),
);
await check(
  "Linked refund uses original sale price after current-price edits",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            {
              id: "refund-source",
              type: "sale_cash",
              productId: "fixture-product",
              productName: "Fixture Tablets 500mg",
              amount: 5000,
              qty: 5,
              unitPrice: 1000,
              unitSellingPrice: 1000,
              costSnapshot: 500,
              ts: new Date().toISOString(),
            },
          ]);
          if (err) throw Error(err);
          const stock = structuredClone(a.getStock());
          stock[0].price = 2000;
          a.setStock(stock);
          return true;
        }, "Sales Desk");
        a.setProduct("fixture-product");
        return [
          a.originalRefundPricing(a.getStock()[0], 2, "refund-source").total,
          a.getTx()[0].amount,
        ];
      }),
      [2000, 5000],
    ),
);
await check(
  "J refund and reversal restore exactly the justified stock movement",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        const row = {
          id: "refund-fixture",
          type: "refund_cash",
          productId: "fixture-product",
          qty: 2,
          amount: 2000,
          unitPrice: 1000,
          costSnapshot: 500,
          originalSaleId: "refund-source",
          returnToStock: true,
          ts: new Date().toISOString(),
        };
        await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([...a.getTx(), row]);
          if (err) throw Error(err);
          return true;
        });
        const after = [
          a.getStock()[0].qty,
          a.calc().expectedCash,
          a.calc().netSales,
        ];
        await a.inventoryCommit(() => {
          const err = a.commitSalesLedger(
            a.getTx().filter((t) => t.id !== "refund-fixture"),
          );
          if (err) throw Error(err);
          return true;
        });
        return [after, a.getStock()[0].qty, a.calc().expectedCash];
      }),
      [[97, 103000, 3000], 95, 105000],
    ),
);
await check(
  "Refund over original sold quantity is rejected without mutation",
  async () =>
    equal(
      await p.evaluate(async () => {
        const a = auditTest;
        const ok = await a.inventoryCommit(() => {
          const err = a.commitSalesLedger([
            ...a.getTx(),
            {
              id: "bad-refund",
              type: "refund_cash",
              productId: "fixture-product",
              qty: 6,
              amount: 6000,
              costSnapshot: 500,
              originalSaleId: "refund-source",
              returnToStock: true,
            },
          ]);
          if (err) throw Error(err);
          return true;
        });
        return [ok, a.getStock()[0].qty, a.getTx().length];
      }),
      [false, 95, 1],
    ),
);
await check(
  "Cross-date reuse of a transaction ID is rejected at backup validation",
  async () =>
    equal(
      await p.evaluate(() => {
        const a = auditTest,
          b = a.backupObject();
        b.saved = [
          {
            id: "bad-day",
            date: "2000-01-01",
            business: "Audit Fixtures",
            tx: structuredClone(a.getTx()),
            fields: {},
            openingStock: {},
            closingStock: {},
          },
        ];
        try {
          a.validateFullBackup(b);
        } catch (e) {
          return /transaction.*(date|day)|identity.*day/i.test(e.message);
        }
        return false;
      }),
      true,
    ),
);
await check(
  "Recent and malformed audit entries cannot be silently discarded",
  async () =>
    equal(
      await p.evaluate(async () => {
        const rs = RoseachyStore,
          k = "roseachy_inventory_audit_v1";
        await rs.atomic(() =>
          rs.setCollection(k, [
            ...rs.getObject(k),
            { id: "malformed-date-fixture", timestamp: "not-a-date" },
          ]),
        );
        try {
          await rs.atomic(() =>
            rs.setCollection(
              k,
              rs.getObject(k).filter((r) => r.id !== "malformed-date-fixture"),
            ),
          );
        } catch (e) {
          return e.message;
        }
        return false;
      }),
      "Recent adjustment history cannot be removed.",
    ),
);
await d.close();
await check(
  "Fallback metadata save propagates storage quota errors",
  async () => {
    const x = await device({ fallback: true });
    equal(
      await x.page.evaluate(async () => {
        const original = Storage.prototype.setItem;
        Storage.prototype.setItem = function (k, v) {
          if (k === "roseachy_metadata_audit-fixture")
            throw new DOMException(
              "Injected quota failure",
              "QuotaExceededError",
            );
          return original.call(this, k, v);
        };
        try {
          await RoseachyStore.meta.set("audit-fixture", true);
          return false;
        } catch (e) {
          return e.name;
        } finally {
          Storage.prototype.setItem = original;
        }
      }),
      "QuotaExceededError",
    );
    await x.close();
  },
);
await check(
  "Older authenticated bank confirmations regain settlement receipts without posting money",
  async () => {
    const x = await device();
    await seed(x.page);
    equal(
      await x.page.evaluate(async () => {
        const a = auditTest;
        a.switchDesk("financial");
        for (const id of ["finSetupPassword", "finSetupPassword2"])
          document.getElementById(id).value = "1234";
        document.getElementById("finAnchorInput").value = "100000";
        document.getElementById("finAnchorMode").value = "day";
        await a.finSetup();
        await a.inventoryCommit(() => {
          a.getTx().push({
            id: "legacy-confirmation",
            type: "supplier_pay_bank",
            amount: 1000,
            qty: 0,
            unitPrice: 0,
            ts: new Date().toISOString(),
            paymentFunding: "business",
          });
          return true;
        }, "Market Desk");
        await a.BankReconciliation.decide("legacy-confirmation", "confirm");
        await RoseachyStore.atomic(() =>
          RoseachyStore.set("roseachy_payment_verifications_v3", "[]"),
        );
        a.switchDesk("sales");
        await a.ready();
        a.switchDesk("financial");
        document.getElementById("finUnlockPass").value = "1234";
        await a.finUnlock();
        const t = a.getTx().find((t) => t.id === "legacy-confirmation");
        return [
          a.finLedger().balanceK,
          a.getFinance().events.length,
          a.BankReconciliation.settledTransaction(t),
        ];
      }),
      [9900000, 1, true],
    );
    await x.close();
  },
);
await fs.writeFile(
  resultsDir +
    "/" +
    (root.includes("/original") ? "baseline-integrity" : "integrity") +
    "-results.json",
  JSON.stringify(results, null, 2),
);
await browser.close();
process.exitCode = results.some((x) => x.status === "failed") ? 1 : 0;
