# Roseachy Desk 2.14.0 — Credit Account corrections

Credit-sale lines can now be corrected through the existing Sales Records Edit form. Inventory and customer receivables update together; existing payments, transaction IDs and bank security are preserved. The existing right-side Credit Account control is the only dedicated account-management entry.

Use Edit on a current-day credit-sale line to change its product, quantity, customer or applicable details. Remove deletes an unpaid product line with the same reconciliation safeguards. Changing customer transfers the entire purchase group; paid purchases or accounts with recorded collections cannot be reassigned safely and are blocked. Prices follow the existing snapshot/product-pricing rules. Historical saved days remain read only.

**Overpayments are blocked:** this app has no purchase-specific allocation/refund workflow for customer collections. A potentially unsafe reduction requires explicit payment resolution before the sale can be adjusted. The editor never deletes or reapplies collections.

## Download and deployment

Extract the Cloudflare Pages ZIP and upload its thirteen root files using Pages Direct Upload. No production dependencies, build command, Worker or backend are required. This release has not been deployed to Cloudflare. The preview ZIP contains HTML only; offline installation needs the complete runtime on HTTPS or localhost.

Local development: `python3 -m http.server 8015` from this directory.

## Verification

```sh
npm ci --prefix tests
npm test --prefix tests
python3 tools/package.py
```

Use Node.js 24+, Python 3 and Chromium (set CHROMIUM_PATH if not at /usr/bin/chromium). Tests use independent synthetic browser profiles. See AUDIT_REPORT.md and VERIFICATION.md for outcomes, safeguards and boundaries. All connected devices should update before exchanging packages containing correction history.

Physical-device, native Android and live Cloudflare checks remain outside the automated environment; this is not exhaustive platform certification.
