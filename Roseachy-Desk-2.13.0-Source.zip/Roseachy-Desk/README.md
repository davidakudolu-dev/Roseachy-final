# Roseachy Desk — Reference Themes

Release **2.13.0-reference-themes**, built from the supplied `Roseachy-Desk-Cloudflare (1).zip` (2.12.2).

Open **Settings → Appearance** to choose seven reference themes or the three preserved original themes. Existing saved theme selections migrate automatically; business records and other appearance preferences retain their existing behavior.

## Preview and Cloudflare Pages

The HTML preview is a downloadable copy of `index.html`. For the complete app, extract the deployment ZIP and serve its contents over HTTP. Upload the 13 runtime files at the ZIP root to Cloudflare Pages using Direct Upload. No build command, Worker, database or production dependency is required. This release has not been deployed to Cloudflare.

For local development:

```sh
python3 -m http.server 8013
```

PWA installation/offline caching requires a supported browser on HTTPS or localhost and the complete runtime directory. A downloaded HTML preview alone does not include the service worker or icon files.

## Development and verification

Node.js 24+ and Chromium are used for development tests only:

```sh
npm ci --prefix tests
npm test --prefix tests
python3 tools/package.py
```

Set `CHROMIUM_PATH` if Chromium is not installed at `/usr/bin/chromium`. See `tests/README.md` for details and `THEME_RECONSTRUCTION.md` for the design map and verification boundaries. `audit/` contains provenance, final test results, screenshots and the source patch.
