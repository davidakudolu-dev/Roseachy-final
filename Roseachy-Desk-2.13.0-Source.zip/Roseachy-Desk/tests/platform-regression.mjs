import { browser, root, resultsDir, baseURL } from "./harness.mjs";
import fs from "node:fs/promises";
import vm from "node:vm";
import { createHash } from "node:crypto";
import { webcrypto } from "node:crypto";
const results = [];
const check = async (name, fn) => {
  try {
    const detail = await fn();
    results.push({ name, status: "passed", detail });
    console.log("PASS", name, detail ?? "");
  } catch (e) {
    results.push({ name, status: "failed", error: e.message });
    console.log("FAIL", name, e.message);
  }
};
function equal(x, y) {
  if (JSON.stringify(x) !== JSON.stringify(y))
    throw Error(`Expected ${JSON.stringify(y)}, got ${JSON.stringify(x)}`);
}
await check("Android bridge preserves CSV export format argument", async () => {
  const received = [],
    win = {
      crypto: webcrypto,
      RoseachyFiles: {
        save: async (...args) => {
          received.push(args);
          return "download";
        },
      },
      AndroidSyncFileBridge: { requestSave() {} },
    };
  win.window = win;
  const context = vm.createContext({
    ...win,
    window: win,
    document: { readyState: "complete" },
    TextEncoder,
    TextDecoder,
    Uint8Array,
    Uint32Array,
    setTimeout,
    clearTimeout,
    btoa,
  });
  vm.runInContext(
    await fs.readFile(root + "/js/android-sync-files.js", "utf8"),
    context,
  );
  await win.RoseachyFiles.save(new Blob(["a,b"]), "fixture.csv", "csv");
  equal(received[0][2], "csv");
});
await check(
  "Original CSS remains byte-identical outside the isolated reference layer",
  async () => {
    const hashes = JSON.parse(
        await fs.readFile(
          new URL("./fixtures/interface-sha256.json", import.meta.url),
          "utf8",
        ),
      ),
      html = await fs.readFile(root + "/index.html", "utf8");
    const hash = (value) => createHash("sha256").update(value).digest("hex");
    equal(
      hash(
        [...html.replace(/<style id="roseachy-reference-themes">[\s\S]*?<\/style>/, "").matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/g)]
          .map((x) => x[1])
          .join("\n"),
      ),
      hashes.styles,
    );

  },
);
const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
  }),
  page = await context.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await check("PWA service worker installs every local shell asset", async () => {
  await page.goto(baseURL);
  await page.waitForFunction(
    () => window.__roseachyFirstUsableMs !== undefined,
  );
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.waitForFunction(() => navigator.serviceWorker.controller);
  await page.waitForFunction(async () => {
    const keys = await caches.keys();
    const c = await caches.open(
      keys.find((k) => k.startsWith("roseachy-shell")),
    );
    return (await c.keys()).length === 11;
  });
  equal(await page.evaluate(() => RoseachyStore.status().mode), "indexeddb");
});
await check(
  "Installed shell reloads offline and retains account records",
  async () => {
    await page.locator("#creditMenuBtn").click();
    await page.locator("#creditMenuEntry").click();
    await page.locator("#creditNew").click();
    await page.locator("#creditName").fill("Offline Fixture");
    await page.locator("#creditConfirm").click();
    await page.waitForSelector("#creditAddProducts");
    await page.evaluate(() => RoseachyStore.whenSaved());
    await context.setOffline(true);
    await page.reload();
    await page.waitForFunction(
      () => window.__roseachyFirstUsableMs !== undefined,
    );
    equal(
      await page.evaluate(() =>
        JSON.parse(RoseachyStore.get("roseachy_credit_customers_v1")).map(
          (c) => c.name,
        ),
      ),
      ["Offline Fixture"],
    );
    await context.setOffline(false);
  },
);
await check(
  "No duplicate DOM identities or uncaught offline errors",
  async () => {
    equal(
      await page.evaluate(() => {
        const ids = [...document.querySelectorAll("[id]")].map((x) => x.id);
        return ids.filter((x, i) => ids.indexOf(x) !== i);
      }),
      [],
    );
    equal(errors, []);
  },
);
await fs.writeFile(
  resultsDir +
    "/" +
    (root.includes("/original") ? "baseline-platform" : "platform") +
    "-results.json",
  JSON.stringify(results, null, 2),
);
await browser.close();
process.exitCode = results.some((x) => x.status === "failed") ? 1 : 0;
