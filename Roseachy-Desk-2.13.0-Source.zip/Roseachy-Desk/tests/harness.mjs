import { chromium } from "playwright";
import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
export const resultsDir =
  process.env.ROSEACHY_RESULTS_DIR ||
  fileURLToPath(new URL("../.test-results/", import.meta.url));
export const baseURL = process.env.ROSEACHY_BASE_URL || "http://127.0.0.1:8000";
await fs.mkdir(resultsDir, { recursive: true });
export const root =
  process.env.ROSEACHY_APP_ROOT ||
  fileURLToPath(new URL("../", import.meta.url)).replace(/\/$/, "");
export const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
export async function device({
  legacy,
  mobile = false,
  fallback = false,
} = {}) {
  const context = await browser.newContext({
    serviceWorkers: "block",
    viewport: mobile
      ? { width: 390, height: 844 }
      : { width: 1280, height: 900 },
  });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("dialog", (d) => d.accept());
  const hook = `window.auditTest={appearanceSafe,getAppearanceSettings,applyAppearanceSettings,themeNames:Object.keys(RS_THEME_SEEDS),CreditAccounts,SmartSync,SyncPrivacy,BankReconciliation,calc,posBuild,packBreakdown,normalizeProduct,setStock,getStock,getSaved,setSaved,getMarketState,setMarketState,applyOneMarketItem,createSupplierPurchaseForApplied,supplierPurchaseOutstanding,supplierPurchasePaid,inventoryCommit,commitSalesLedger,rebuildStockFromOpening,stockSnapshot,saveDraft,recordObject,render,setTab,switchDesk,stockPackSync,marketRecalcForm,openMarketReview,openSupplierPayment,setNotes,getNotes,finTxImpact,finLedger,finSetup,finUnlock,finPersist,backupObject,roseachySafeBackup,validateFullBackup,restoreFullBackup,applyBackupData,backupCompareStored,cleanAdjustmentHistory,validateSystemIntegrity,setupInventoryPicker,applyInventoryAdjustment,salePricing,originalRefundPricing,smartProductMatches,
 getTx:()=>tx,setTx:v=>{tx=v;},setOpening:v=>{openingStock=v;},getOpening:()=>openingStock,
 setProduct:v=>{selectedProductId=v;},getFinance:()=>finPrivate,
 finance:async()=>{finKey=await crypto.subtle.generateKey({name:'AES-GCM',length:256},true,['encrypt','decrypt']);finPrivate={version:1,anchor:{amountK:10000000,asOf:'2020-01-01T00:00:00.000Z'},events:[],reviews:[]};const box=await finSeal(finKey,new TextEncoder().encode(JSON.stringify(finPrivate)));await RS.atomic(()=>storeSet(FIN_META,JSON.stringify({version:1,vault:box})));currentDesk='financial';finEntered=true;},
 getView:()=>({historical,currentDesk,holdMode,inventoryBusy}),ready:()=>RS.whenSaved()};`;
  await context.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.origin !== baseURL) return route.abort();
    if (url.pathname === "/" || url.pathname === "/index.html") {
      let html = await fs.readFile(root + "/index.html", "utf8");
      html = html.replace(
        "window.__roseachyDebug={",
        hook + "\nwindow.__roseachyDebug={",
      );
      return route.fulfill({ contentType: "text/html", body: html });
    }
    return route.continue();
  });
  if (fallback)
    await page.addInitScript(() =>
      Object.defineProperty(window, "indexedDB", { value: undefined }),
    );
  if (legacy)
    await page.addInitScript((data) => {
      if (!sessionStorage.getItem("fixture-seeded")) {
        for (const [k, v] of Object.entries(data))
          localStorage.setItem(k, JSON.stringify(v));
        sessionStorage.setItem("fixture-seeded", "1");
      }
    }, legacy);
  await page.goto(baseURL);
  await page.waitForFunction(
    () =>
      window.__roseachyFirstUsableMs !== undefined ||
      document.querySelector("#loadErrorOverlay"),
  );
  const error = await page.evaluate(
    () => document.querySelector("#loadErrorOverlay")?.textContent,
  );
  if (error) throw Error(error);
  await page.evaluate(() => auditTest.ready());
  return { context, page, errors, close: () => context.close() };
}
export async function seed(page, { qty = 100, price = 1000, cost = 500 } = {}) {
  return page.evaluate(
    async ({ qty, price, cost }) => {
      const a = auditTest,
        rs = RoseachyStore;
      document.querySelector("#business").value = "Audit Fixtures";
      document.querySelector("#openingCash").value = "100000";
      const p = a.normalizeProduct({
        id: "fixture-product",
        name: "Fixture Tablets 500mg",
        qty,
        totalUnits: qty,
        price,
        costPrice: cost,
        currentCostPrice: cost,
        priceMode: "manual",
        markupMode: "custom",
        division: "pharmacy",
        packEnabled: true,
        unitsPerPack: 12,
        batches: [
          {
            id: "fixture-batch",
            qty,
            costPrice: cost,
            createdAt: "2026-01-01T00:00:00.000Z",
          },
        ],
      });
      await a.inventoryCommit(() => {
        a.setStock([p]);
        a.setOpening(a.stockSnapshot());
        a.saveDraft();
        return true;
      }, "Fixture");
      await rs.whenSaved();
      return p.id;
    },
    { qty, price, cost },
  );
}
