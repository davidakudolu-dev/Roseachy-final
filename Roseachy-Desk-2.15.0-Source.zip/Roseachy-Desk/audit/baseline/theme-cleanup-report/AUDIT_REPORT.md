# Theme cleanup report — 2.14.1

## Completed cleanup

Removed Lunar Glass, Acid Ledger, Violet Wallet and Teal & Apricot from the selector and runtime. Their eight light/dark palette/finish configurations, previews, exclusive gradients/shadows/glows, removed-target alias entries, Lunar-only backdrop-filter selector and shell-text conditional are absent. The optional metric-finish branch is removed because no remaining theme supplies it. Shared metric/table variables remain where active themes use them, especially Mono Mint's table surface overrides.

All thirteen deployment files were inspected for active theme references. The shared logo, icons, PWA assets and Android bridge are not theme-specific and were retained. There were no separate runtime image files exclusive to the deleted themes. Historical baseline ZIPs, prior reports and obsolete-theme migration fixtures remain in the source's audit/tests directories for reproducibility; they are not loaded by the application and are not present in the deployment ZIP.

The six retained theme definitions are deeply equal to their 2.14.0 counterparts: Cobalt Studio, Midnight & Ember, Pearl & Royal Blue, Cyan Flux, Coral Carbon and Mono Mint. Sampled normal computed styles match the baseline in both modes across Sales, Market, Financial Desk, Credit Accounts and Smart Sync. Existing protected-theme screenshots and responsive/navigation checks remain part of regression. The application structure and interface were not redesigned.

## Preference migration and preservation

Generic registry membership validation resolves any unsupported saved identifier to Cobalt Studio. The runtime does not keep an obsolete-theme identifier list or evaluate removed configurations. Obsolete aliases whose targets no longer exist also fall back to Cobalt. Aliases to supported themes retain their previous mappings. A fresh installation retains the existing default configuration.

When a stored theme normalizes to a replacement, getAppearanceSettings persists a copy of the original preference object with only its theme field changed. This avoids resetting other raw preferences or custom fields. The existing normalizer continues to provide valid runtime settings. Reload tests verify persistence for each removed identifier while retaining font size, density, mode, shadow intensity, pricing and a custom sentinel field, as well as stored business notes.

Four genuine, integrity-protected backups exported by the previous build were restored into fresh current-version profiles. Each obsolete preference became persisted Cobalt; all tests retained 95 stock units, the original sale/payment IDs, the 3,000 receivable, notes and unrelated appearance settings. Credit Accounts still opened through the right-side control. Backup verification was not bypassed or weakened.

Smart Sync does not transport personal visual themes; its shared appearance projection contains pricing only. That behavior and all sync security checks are unchanged. Existing full backups carry visual preferences and use the same normalization on restore.

## Workload reduction

The selector previously called saveAppearanceSettings, which applied the palette, then renderAppearanceControls, which applied it a second time. The control renderer now accepts an optional apply flag; callers that already applied the saved settings refresh controls without repeating the palette application. Section resets and default resets use the same path. The system color-scheme handler now invokes the renderer once rather than applying twice.

No global theme cache, engine rewrite, framework or production dependency was introduced. Existing token cleanup remains active, including removing stale reference tokens when returning to a protected theme. An injected obsolete glass token is cleared during switching in the regression test.

Instrumentation measures two appearance applications per selector click before cleanup and one after. Two-frame switching timings over the same 30 selections are reported in VERIFICATION.md. Timing varies with browser scheduling; similar median/p95 results do not establish a user-visible speed improvement. Bundle reduction is measured separately in raw and gzip bytes.

## Executable verification

The 17 added cleanup checks cover exact supported choices, absence of removed runtime identifiers, retained definitions, four persisted migrations, generic fallback, four old-version backup restores, six baseline style comparisons, repeated selection/reload/token clearing, switching instrumentation/timings and uncaught errors.

Existing regression includes credit editing/payment preservation/rollback, independent sync contexts, full business simulations, PWA offline reload, protected-theme visuals, mobile/tablet bounds and navigation. The contrast scan now covers six themes × two modes × eight screens = 96 sampled states, including locked/unlocked Financial Desk, Credit Accounts and Smart Sync. Theme viewport checks cover the three retained reference themes; protected-theme comparisons still include mobile and desktop.

The source-boundary check compares against preserved 2.14.0 and permits only the documented appearance functions, configuration objects and theme handlers. All business code and twelve non-HTML runtime assets remain unchanged. Exact counts and execution logs are under audit/final and VERIFICATION.md.

## Boundaries

No claim is made of exhaustive accessibility or platform certification. Physical devices, native Android file pickers and live Cloudflare headers/install behavior remain unverified. The Cloudflare archive is structurally and byte-verified but has not been deployed.

Existing credit protections remain: current-day sales use the existing editor; historical days remain read only; captured prices are preserved; unsafe overpayment reductions and reassignment of accounts with collections are blocked. This cleanup neither removes those fixes nor introduces a payment-allocation feature.

## Delivery

The Cloudflare ZIP contains only the thirteen runtime files at its root. The source ZIP includes the complete project, tests, lockfile, packaging tool, request, provenance, results and reports. The HTML preview and preview ZIP are provided separately. SHA256-MANIFEST.json records artifact hashes and runtime hashes.
