# Roseachy Desk 2.14.1 — theme cleanup

This release retains the credit-sale editing, single right-side Credit Accounts access and integrity repairs from 2.14.0. It removes four unused visual systems and keeps six themes:

- Cobalt Studio
- Midnight & Ember
- Pearl & Royal Blue
- Cyan Flux
- Coral Carbon
- Mono Mint

Unsupported saved theme identifiers automatically become Cobalt Studio and the replacement is persisted. Other preferences and business records are preserved. Full backups receive the same handling when restored. A new profile retains its existing default theme.

## Preview and deploy

Extract the Cloudflare Pages ZIP and upload its thirteen root files through Pages Direct Upload. No build command, Worker, backend or production dependency is required. Packaging does not deploy to Cloudflare. The standalone HTML/preview ZIP is for preview; offline installation requires the complete runtime served through HTTPS or localhost.

Local development: `python3 -m http.server 8016` from the extracted directory.

## Verify

```sh
npm ci --prefix tests
npm test --prefix tests
python3 tools/package.py
```

Requirements: Node.js 24+, Python 3 and Chromium. Set CHROMIUM_PATH if Chromium is not at /usr/bin/chromium. Tests use isolated synthetic profiles.

See AUDIT_REPORT.md and VERIFICATION.md for cleanup, migration evidence, bundle-size and timing measurements. Physical devices, native Android file handling and live Cloudflare remain outside the automated test environment.

Credit edits retain existing protections: historical days are read only, completed prices follow captured pricing, unsafe overpayment reductions and customer transfers are blocked, and collection records are preserved.
