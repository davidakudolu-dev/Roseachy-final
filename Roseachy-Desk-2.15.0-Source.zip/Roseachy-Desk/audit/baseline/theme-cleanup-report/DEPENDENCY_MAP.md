# Theme cleanup boundaries

| Area | Responsibility |
|---|---|
| index.html theme registry | Six retained configurations; no removed-theme runtime entries |
| appearanceSafe / getAppearanceSettings | Validate supported preferences and persist Cobalt fallback without resetting other saved fields |
| saveAppearanceSettings / renderAppearanceControls | Apply saved appearance once and refresh selector controls |
| rsApplyReferenceTheme | Shared tokens for three retained reference themes; obsolete exclusive branches removed |
| Credit, inventory, finance, backup, Smart Sync | Existing 2.14.0 implementation unchanged |
| sw.js, manifest.json, js/*, icons/*, Pages headers/redirects | Twelve unchanged shared runtime files |
| tests/theme-cleanup-regression.mjs | Baseline comparisons, migrations, real old backups, reference audit and measured switching workload |
| tools/package.py | Thirteen-file deployment ZIP, source and previews with integrity/hash verification |

Historical source and evidence are test/audit inputs only. No audit/test file is part of the Pages runtime ZIP.
