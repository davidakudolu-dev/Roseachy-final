# 2.14.1-theme-cleanup — 2026-10-20

- Remove Lunar Glass, Acid Ledger, Violet Wallet and Teal & Apricot selector cards and complete light/dark configuration objects.
- Remove their obsolete alias targets, Lunar-only backdrop blur and shell-text branch, and the now-unused optional metric finish override.
- Retain all six supported theme definitions unchanged; preserve shared table tokens required by Mono Mint and other retained themes.
- Normalize unsupported preferences to Cobalt Studio and persist only the replacement theme in existing stored preference objects.
- Apply the same safe normalization during full-backup restoration; Smart Sync still shares pricing rather than personal appearance choices.
- Remove duplicate appearance application after theme changes, section/default resets and system-color changes.
- Add 17 cleanup/migration/style/workload checks and adapt existing theme/contrast coverage to the supported registry.

No business, inventory, credit, Financial Desk, sync or backup schema change. All twelve non-HTML runtime files are unchanged.
