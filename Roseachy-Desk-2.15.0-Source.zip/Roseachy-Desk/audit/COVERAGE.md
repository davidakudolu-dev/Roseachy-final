# Current acceptance coverage

| Requirement | Executable evidence |
|---|---|
| Unpaid purchase retained, no Daily receipt | credit-daily day 1, credit-daily-sync offline purchase |
| Initial partial receipt, multi-line grouping | credit-daily 40000/12000 scenario |
| Actual business-day installments | Four-day UI save/start-day simulation |
| Turnover vs collections, stock only once | Independent day totals and finance assertions |
| Search/details/export | Customer/method search, expanded receipt details, downloaded CSV |
| Purchase edit from account history | Credit-edit suite and credit-daily existing-editor test |
| Quantity/product/customer/credit-limit safeguards | Twenty credit-edit checks |
| Receipt amount/source correction, reversal | Daily and signed peer simulations, owner bank confirmation |
| Paid cancellation/overpayment | Explicit blocked state equality; upfront reversal then unpaid cancellation |
| Atomic and repeat submission | Real IndexedDB abort, saved-copy equality, rapid clicks, stale editor |
| Sync once / conflicts | Two-device receipt suite, existing credit conflicts and four-context suite |
| Restart/backups/legacy | Round trips, old-build migration, legacy ambiguity projection |
| Single right-side entry / left menu | Navigation suite, four widths × six themes × two modes |
| Back, rapid taps, modals, orientation, swipe | Navigation suite and existing theme workflow checks |
| Offline/PWA | Chromium service-worker install and offline restart |
| Unrelated behavior preserved | Supplied-source AST boundary, assets, existing workflow/system/performance suites |

Exact pass/fail counts and full results are in VERIFICATION.md and audit/final. Read-only historical editing, missing legacy payment allocations, unsupported refund allocation, and physical/live deployment limitations are disclosed in AUDIT_REPORT.md.
