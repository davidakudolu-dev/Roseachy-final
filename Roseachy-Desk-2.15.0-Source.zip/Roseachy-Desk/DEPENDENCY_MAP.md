# Affected paths

| Component | Responsibility / source |
|---|---|
| `dailyRecordRows` | Read-only view of the day's authoritative transactions; never passed into accounting or persistence |
| `renderLedger`, `txLabel`, `txRecordDetailsHtml`, CSV handler | Receipt presentation, search, details and export |
| `startTransactionEdit` | Shared existing purchase-editor opener, also called from account history |
| `CreditAccounts.editLine` | Existing quantity/total difference reconciliation and payment/customer safeguards |
| `CreditAccounts.correctPayment` | Same-ID payment/source correction or upfront allocation adjustment, audited and atomic |
| `CreditAccounts.voidGroup` | Existing reversal/trash pathway with paid-purchase cancellation safeguard |
| `commitSalesLedger` / `inventoryCommit` | Unchanged inventory validation, persistence transaction, rollback and sync observation |
| `calc` | Unchanged turnover, profit, cash and bank calculations from full authoritative ledger |
| `BankReconciliation` / Financial Desk | Unchanged owner confirmation, exact-once bank effect and encrypted PIN gate |
| `SyncPrivacy.transaction` | Whitelists payment business date and correction method/type in shared audit snapshots |
| Smart Sync merge / backup controllers | Unchanged merge/conflict, stock delta and restore mechanisms |
| Header / `switchDesk` | Dedicated Sales control and active state; existing navigation/back architecture |

The AST boundary check compares all other JavaScript against the attached 2.14.3 runtime. Eleven other runtime assets are identical; service-worker code differs only in its release identifier. Header styling is isolated in `creditDailyNavigationStyles`.
