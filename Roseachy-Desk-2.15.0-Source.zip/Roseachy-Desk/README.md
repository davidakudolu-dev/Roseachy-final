# Roseachy Desk 2.15.0 — credit receipts and navigation

Based on the supplied `Roseachy-backup-main.zip` (2.14.3). Supplier-payment enhancements, six retained themes, inventory and Financial Desk protections are preserved.

Daily Records displays actual Credit Account receipts. An unpaid purchase stays in the authoritative ledger and account history; it does not appear as money collected. Initial receipts are derived from purchase allocations, and later receipts from their original payment records. Nothing is copied into a second editable financial ledger.

Use the right-side Credit Accounts button, select the customer, expand the purchase in Transaction History, and select Edit. The existing product editor preserves IDs and payments and reconciles stock/obligation differences. Current-day receipt Edit reuses the payment form to correct amount or method. Reverse retains an audit trail. Bank changes still require Financial Desk owner confirmation.

Sales Desk has a dedicated top-right control using the existing header-button styling, beside the unchanged Credit Accounts control. The left menu retains Market, Financial Desk and Settings.

## Preview / Cloudflare Pages

Extract the Cloudflare Pages ZIP and upload its thirteen root files using Pages Direct Upload. No build command, Worker, backend or production dependency is required. No Cloudflare deployment was performed.

For local preview, run `python3 -m http.server 8017` in the extracted directory. The single HTML preview opens the interface; use the complete runtime over HTTPS or localhost for offline/PWA installation.

## Verify and package

```sh
npm ci --prefix tests
npm test --prefix tests
python3 tools/package.py
```

Requires Node.js 24+, Python 3 and Chromium (`CHROMIUM_PATH` overrides `/usr/bin/chromium`). Tests use isolated synthetic business records. See VERIFICATION.md, AUDIT_REPORT.md and audit/final for executed evidence and limitations.
