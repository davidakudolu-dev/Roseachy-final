# 2.15.0-credit-daily — 2026-10-22

- Derived Daily Records receipts show only initial amounts received and later customer collections. Unpaid credit purchases remain in account history and accounting/inventory sources.
- Grouped initial receipts retain stable references; later receipts retain their original ID. Search, details, CSV export and historical views use the payment representation. New credit records retain their business date through backup and sync.
- Purchase History opens the existing Sales Records editor, including product removal and stock-difference reconciliation.
- Current-day receipt corrections reuse the payment form. Amount/source edits preserve IDs and timestamp, update saved-day copies atomically, retain before/after audit, and use existing bank approval.
- Reversals retain the original in the existing recycle-bin/audit model. Paid purchase cancellation is blocked until refunds/allocations are explicitly resolved. No unsupported customer-credit/refund balance is silently invented.
- Added dedicated top-right Sales Desk control using established header styling, per user preference. Removed its left-menu entry. Preserved the supplied right-side Credit Accounts button, icon, position and opening behavior.
- Preserved supplied supplier-payment changes and the six-theme cleanup. Corrected the retained-theme description and bumped the service-worker release identifier.
- Added four-day reconciliation, receipt/export/correction/rollback, signed two-device and navigation simulations. Updated older test entry points to the supplied backup's current controls.
