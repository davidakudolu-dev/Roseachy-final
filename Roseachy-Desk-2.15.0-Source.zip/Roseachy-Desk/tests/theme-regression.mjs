import {verifySourceBoundary} from './source-boundary.mjs';
import {browser,device,root,resultsDir,baseURL} from './harness.mjs';
import {contrastSamples} from './theme-inspect.mjs';
import fs from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const original=execFileSync('python3',['-c','import zipfile,sys;sys.stdout.buffer.write(zipfile.ZipFile(sys.argv[1]).read("index.html"))',root+'/audit/original-input.zip'],{maxBuffer:3e6}).toString();
const current=await fs.readFile(root+'/index.html','utf8');
const results=[];const check=async(name,fn)=>{try{const detail=await fn();results.push({name,status:'passed',detail});console.log('PASS',name)}catch(e){results.push({name,status:'failed',error:e.message});console.log('FAIL',name,e.message.slice(0,3500))}};
const hash=s=>createHash('sha256').update(s).digest('hex');
const auditBaseline=execFileSync('python3',['-c','import zipfile,sys;sys.stdout.buffer.write(zipfile.ZipFile(sys.argv[1]).read("Roseachy-backup-main/index.html"))',root+'/audit/baseline/2.14.3-runtime.zip'],{maxBuffer:3e6}).toString();
await check('Production script changes stay within the documented repair boundaries',async()=>verifySourceBoundary(auditBaseline,current));
await check('Supplied DOM is unchanged outside the dedicated Sales control and theme description',async()=>{
 const clean=s=>s.slice(s.indexOf('<body'),s.indexOf('<script>')).replace(/<button id="salesDeskBtn"[\s\S]*?<\/button>/,'').replace('<button type="button" data-desk="sales" class="active">Sales Desk</button>','').replace('Three original themes and seven reference designs.','Three original themes and three reference designs.');
 assert.equal(hash(clean(current)),hash(clean(auditBaseline)));
});
await check('Supplied runtime assets remain identical except service-worker release version',async()=>{
 const output=execFileSync('python3',['-c',`import zipfile,sys,pathlib,re
z=zipfile.ZipFile(sys.argv[1]);r=pathlib.Path(sys.argv[2]);names=[n for n in z.namelist() if not n.endswith('/') and not n.endswith('/index.html')]
for n in names:
 a=z.read(n);b=(r/pathlib.Path(n).relative_to('Roseachy-backup-main')).read_bytes()
 if n.endswith('/sw.js'): a=re.sub(rb"const VERSION = '[^']*'",b"const VERSION = 'release'",a);b=re.sub(rb"const VERSION = '[^']*'",b"const VERSION = 'release'",b)
 assert a==b,n
print(len(names))`,root+'/audit/baseline/2.14.3-runtime.zip',root]).toString().trim();assert.equal(output,'12');
});
const d=await device(),p=d.page;
const protectedKeys=['cobalt','ember','pearl'];const newKeys=['cyanflux','coralbank','monomint'];
await check('Registry exposes exactly three protected and three unique reference themes',async()=>{
 assert.deepEqual((await p.evaluate(()=>auditTest.themeNames)).sort(),[...protectedKeys,...newKeys].sort());
 for(const key of protectedKeys){const line=s=>s.split('\n').find(x=>x.trim().startsWith(key+':Object.freeze('));assert.equal(line(current),line(original));}
});
await check('All prior theme IDs and invalid preferences map safely without changing default configuration',async()=>{
 const migration=JSON.parse(await fs.readFile(root+'/audit/theme-map.json','utf8')).migration;
 for(const [theme,expected] of Object.entries(migration))assert.equal(await p.evaluate(theme=>auditTest.appearanceSafe({version:15,theme}).theme,theme),expected);
 assert.equal(await p.evaluate(()=>auditTest.appearanceSafe({version:15,theme:'missing'}).theme),'cobalt');
 assert.equal(current.match(/const APPEARANCE_DEFAULTS=.*?;\n/)[0],auditBaseline.match(/const APPEARANCE_DEFAULTS=.*?;\n/)[0]);
});
await check('Protected themes retain their original appearance outside the documented audit contrast layer',async()=>{
 await p.evaluate(()=>document.getElementById('roseachy-audit-contrast').sheet.disabled=true);
 const ctx=await browser.newContext({serviceWorkers:'block'}),baseline=await ctx.newPage();
 const hook='window.auditTest={getAppearanceSettings,applyAppearanceSettings,switchDesk,setTab};';
 await ctx.route('**/*',r=>new URL(r.request().url()).pathname==='/'?r.fulfill({contentType:'text/html',body:auditBaseline.replace('async function init(){',hook+'async function init(){')}):r.continue());
 await baseline.goto(baseURL);await baseline.waitForFunction(()=>window.auditTest&&window.__roseachyFirstUsableMs!==undefined);
 await baseline.evaluate(()=>document.getElementById('roseachy-audit-contrast').sheet.disabled=true);
 const freeze='.appBrand,.appBrand *{visibility:hidden!important}*,*::before,*::after{transition:none!important;animation:none!important}';
 const freezeTags=await Promise.all([baseline.addStyleTag({content:freeze}),p.addStyleTag({content:freeze})]);
 const differences=[],antialiasing=[];let count=0;
 for(const width of [390,1280])for(const theme of protectedKeys)for(const colorMode of ['light','dark'])for(const desk of ['sales','market','financial']){
  for(const page of [baseline,p]){await page.setViewportSize({width,height:900});await page.evaluate(({theme,colorMode,desk})=>{auditTest.switchDesk(desk);auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode});scrollTo(0,0)},{theme,colorMode,desk});}
  await Promise.all([baseline.waitForTimeout(200),p.waitForTimeout(200)]);
  await Promise.all([baseline.evaluate(()=>document.activeElement?.blur()),p.evaluate(()=>document.activeElement?.blur())]);
  for(const page of [baseline,p])await page.evaluate(async()=>{await Promise.all(document.getAnimations().filter(a=>a.effect?.getTiming().iterations!==Infinity).map(a=>a.finished.catch(()=>{})));await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))});
  const [before,after]=await Promise.all([baseline.screenshot({animations:'disabled'}),p.screenshot({animations:'disabled'})]);
  // The existing rotated chevron can rasterize slightly differently across contexts.
  // Require identical computed styles/geometry and exact pixels everywhere else.
  const chevrons=()=>[...document.querySelectorAll('.collapseHead .chev')].map(el=>{const s=getComputedStyle(el),r=el.getBoundingClientRect();return {rect:{x:r.x,y:r.y,width:r.width,height:r.height},style:[...s].filter(k=>!k.startsWith('--audit-')).sort().map(k=>[k,s.getPropertyValue(k)])}});
  const [oldChevrons,newChevrons]=await Promise.all([baseline.evaluate(chevrons),p.evaluate(chevrons)]);
  assert.deepEqual(newChevrons,oldChevrons);
  const rects=newChevrons.map(x=>x.rect);
  let pixels={maxDelta:0,changed:0,outside:0,total:width*900};
  if(hash(before)!==hash(after))pixels=await p.evaluate(async ({data,rects,width})=>{const images=await Promise.all(data.map(async b64=>{const img=await createImageBitmap(await (await fetch('data:image/png;base64,'+b64)).blob());const c=document.createElement('canvas');c.width=img.width;c.height=img.height;const ctx=c.getContext('2d');ctx.drawImage(img,0,0);return ctx.getImageData(0,0,c.width,c.height).data}));let maxDelta=0,changed=0,outside=0;for(let i=0;i<images[0].length;i+=4){let delta=0;for(let k=0;k<3;k++)delta=Math.max(delta,Math.abs(images[0][i+k]-images[1][i+k]));if(delta){changed++;const x=(i/4)%width,y=Math.floor(i/4/width);if(!rects.some(r=>x>=Math.floor(r.x)&&x<Math.ceil(r.x+r.width)&&y>=Math.floor(r.y)&&y<Math.ceil(r.y+r.height)))outside++;}maxDelta=Math.max(maxDelta,delta)}return{maxDelta,changed,outside,total:images[0].length/4}},{data:[before.toString('base64'),after.toString('base64')],rects,width});
  if(pixels.changed)antialiasing.push({width,theme,colorMode,desk,...pixels});
  if(pixels.outside||pixels.maxDelta>16||pixels.changed>pixels.total*.00005){differences.push({width,theme,colorMode,desk,...pixels});await fs.writeFile(resultsDir+`/protected-${width}-${theme}-${colorMode}-${desk}-before.png`,before);await fs.writeFile(resultsDir+`/protected-${width}-${theme}-${colorMode}-${desk}-after.png`,after)}count++;
 }
 await p.evaluate(()=>document.getElementById('roseachy-audit-contrast').sheet.disabled=false);await freezeTags[1].evaluate(el=>el.remove());await ctx.close();assert.deepEqual(differences,[]);return {pixelComparisons:count,antialiasing,tolerance:"Exact pixels outside identical-styled chevrons; at most 0.005% pixels, channel delta <=16 inside chevrons"};
});
const selectors=['.appBrand h1','.deskName','#date','#ref','#note','.collapseHead','.collapseInner label','.card .help','button.primary','.metric.hero strong','.metric.hero span','.metric:not(.hero) strong','.metric:not(.hero) span','.marketViewTabs button.active','.previewTabs button:not(.active)','.previewBadge','.previewCard>small','.marketPanel h3','.settingsGroup summary','.finPinDigit','.previewInput','.tablewrap th','.marketSummaryBar','#moveCashBtn','.advancedNote','#touchRippleStatus'];
await check('Theme foregrounds meet 4.5:1 against sampled surfaces and gradient endpoints',async()=>{
 const evidence=[];const failures=[];
 for(const theme of newKeys)for(const colorMode of ['light','dark']){
  await p.evaluate(({theme,colorMode})=>auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode}),{theme,colorMode});await p.waitForTimeout(350);const samples=await p.evaluate(contrastSamples,selectors);evidence.push({theme,colorMode,samples});failures.push(...samples.filter(x=>!x.missing&&x.ratio<4.5).map(x=>({theme,colorMode,...x})));
 }
 await fs.writeFile(resultsDir+'/theme-contrast.json',JSON.stringify(evidence,null,2));assert.deepEqual(failures,[]);return {themeModes:6,samples:evidence.flatMap(x=>x.samples).filter(x=>!x.missing).length};
});
await check('New themes retain viewport bounds throughout Sales, Stock, Market, Financial and Settings',async()=>{
 const failures=[];let count=0;
 for(const width of [390,768,1280]){await p.setViewportSize({width,height:900});for(const theme of newKeys)for(const colorMode of ['light','dark'])for(const desk of ['sales','stock','market','financial','settings']){
  await p.evaluate(({desk,theme,colorMode})=>{auditTest.switchDesk(desk==='stock'?'sales':desk);if(desk==='stock')auditTest.setTab('Stock');else if(desk==='sales')auditTest.setTab('Tx');auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode});scrollTo(0,0)},{desk,theme,colorMode});
  if(desk==='sales'||desk==='stock')assert.equal(await p.locator(desk==='sales'?'#tabTx':'#tabStock').isVisible(),true);
  const overflow=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);if(overflow)failures.push({width,theme,colorMode,desk});count++;
 }}assert.deepEqual(failures,[]);return {deskChecks:count};
});
await check('Repeated theme switching removes reference tokens before a protected theme and persists choices',async()=>{
 for(const key of ['cyanflux','coralbank','cobalt','ember','pearl']){
  await p.evaluate(key=>auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme:key}),key);
  const state=await p.evaluate(()=>({key:document.documentElement.dataset.rsReferenceTheme,tokens:[...document.documentElement.style].filter(k=>k.startsWith('--rt-'))}));
  if(protectedKeys.includes(key)){assert.equal(state.key,undefined);assert.deepEqual(state.tokens,[])}else assert.equal(state.key,key);
 }
 await p.evaluate(()=>auditTest.switchDesk('settings'));await p.locator('[data-theme-choice="cyanflux"]').click();await p.locator('[data-setting-buttons="colorMode"] [data-value="dark"]').click();await p.evaluate(()=>auditTest.ready());await p.reload();await p.waitForFunction(()=>window.auditTest&&window.__roseachyFirstUsableMs!==undefined);assert.equal(await p.locator('body').getAttribute('data-theme'),'cyanflux');assert.equal(await p.locator('body').getAttribute('data-color-mode'),'dark');
});
await check('Theme CSS never changes geometry, animation, transitions or touch handling',async()=>{
 const allowed=['background','background-color','background-image','background-position-x','background-position-y','background-size','background-repeat','background-attachment','background-origin','background-clip','color','font-family','border-color','border-top-color','border-right-color','border-bottom-color','border-left-color','-webkit-text-fill-color','box-shadow','backdrop-filter','caret-color','color-scheme','opacity','outline-color'];
 const unexpected=await p.evaluate(allowed=>{const result=[];function walk(rules){for(const r of rules){if(r.cssRules)walk(r.cssRules);if(r.style)for(const prop of r.style)if(!allowed.includes(prop))result.push(prop)}}walk(document.getElementById('roseachy-reference-themes').sheet.cssRules);return [...new Set(result)]},allowed);assert.deepEqual(unexpected,[]);
 const sample=async disabled=>p.evaluate(disabled=>{document.getElementById('roseachy-reference-themes').sheet.disabled=disabled;const props=['animationName','animationDuration','animationTimingFunction','transitionProperty','transitionDuration','transitionTimingFunction','touchAction','position','padding','margin','borderRadius','width','height'];return [...document.querySelectorAll('#rsMainTabs,button,.tabInd,.collapseBody,.brandLogo')].map(el=>{const s=getComputedStyle(el);return props.slice(0,11).map(k=>s[k])})},disabled);assert.deepEqual(await sample(true),await sample(false));
});
await check('Mobile tab clicks, synthetic swipes and Credit dialogs work with the new themes',async()=>{
 await p.setViewportSize({width:390,height:844});await p.evaluate(()=>{auditTest.switchDesk('sales');auditTest.setTab('Tx')});await p.locator('#tabBtnStock').click();await p.waitForFunction(()=>!document.getElementById('tabStock').classList.contains('hidden'));await p.locator('#tabBtnTx').click();
 await p.evaluate(()=>{const target=document.getElementById('txEntryCard'),touch=x=>new Touch({identifier:1,target,clientX:x,clientY:300});for(const [type,x,ended] of [['touchstart',320,false],['touchmove',120,false],['touchend',60,true]])target.dispatchEvent(new TouchEvent(type,{bubbles:true,cancelable:true,touches:ended?[]:[touch(x)],changedTouches:[touch(x)]}));});await p.waitForFunction(()=>!document.getElementById('tabStock').classList.contains('hidden'),null,{timeout:3000});
 await p.locator('#creditAccountsBtn').click();await p.locator('#creditNew').click();await p.locator('#creditName').fill('Theme fixture');await p.locator('#creditConfirm').click();await p.waitForSelector('#creditAddProducts');
});
await check('No uncaught browser errors during theme verification',async()=>assert.deepEqual(d.errors,[]));
await fs.writeFile(resultsDir+'/theme-results.json',JSON.stringify(results,null,2)+'\n');await browser.close();process.exitCode=results.some(x=>x.status==='failed')?1:0;
