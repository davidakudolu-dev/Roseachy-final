# Executable regression suite

From the project root run `npm ci --prefix tests` then `npm test --prefix tests`. Requires Node 24+, Python and Chromium; set CHROMIUM_PATH if needed. The runner serves the static site and writes .test-results, propagating failures. Production HTML contains no test hooks; the harness injects them before initialization in isolated synthetic profiles.

New suites: credit-daily-regression (four business days, collection-only records, payment corrections/source/reversal, initial deposits, CSV/details, backup, legacy ambiguity and forced-write rollback), credit-daily-sync (signed independent-device purchase/payment/correction/reversal and stale editor), navigation-regression (single access, six themes in both modes at four widths, Back/modal/rapid taps/orientation/swipes).

Earlier credit-edit, integrity, supplier, finance, sync, failure, 500-sale system, performance, offline PWA, theme migration and contrast suites remain. The test entry selectors follow the supplied 2.14.3 backup. Protected visual comparisons use that baseline, masking only the authorized header area; the separate navigation suite verifies header geometry. Source-boundary tests permit the documented functions and credit module while protecting all other JavaScript. Runtime asset comparison permits only the service-worker release identifier.

Theme migration still uses genuine 2.14.0 backups. Active retained palettes must match exactly. Theme cleanup size/latency are measured, without claiming that later business features shrink the whole file. Contrast samples six themes × two modes × eight screen states; disabled controls are excluded. This is not exhaustive accessibility certification.

ROSEACHY_BASE_URL runs individual suites against an existing server; ROSEACHY_APP_ROOT and ROSEACHY_RESULTS_DIR override locations. Release evidence is copied into audit/final. Physical-device/native bridge behavior and production Cloudflare are outside this local environment.
