# Reproduce the system audit

From the project root run `npm ci --prefix tests` then `npm test --prefix tests`. Requirements: Node.js 24+, Chromium (`CHROMIUM_PATH`, default `/usr/bin/chromium`), and Python 3 for packaging. The runner starts a temporary HTTP server and propagates suite failures. Results are written to `.test-results/`.

Each browser context has synthetic records and isolated storage. PIN 1234 is a test fixture. The harness exposes closure internals only by intercepting test responses; shipped HTML contains no audit hooks. Workflow simulations combine real DOM controls with production business APIs. The 500-sales run exercises the Add control; 10,000/50,000-record stress cases use batched production ledger APIs, not individual clicks. Four devices are four independent browser contexts on one Chromium installation.

| Suite | Coverage |
|---|---|
| static-audit | JavaScript scope, unused variables, duplicate keys, unreachable code |
| regression / workflow / integrity | Sales, credit, supplier funding, rollback, legacy restore, PIN, fees, refunds and transfer integrity |
| sync / multidevice | Signed pairing, independent histories, four-context merges, repeats, stale restores, tampering and private boundaries |
| platform | Actual service-worker offline reload, runtime structure and mocked Android bridge |
| repair / failure | Five initial reproductions, invalid inputs, aborted writes, interrupted saves, cache equivalence and private fingerprints |
| financial | Controlled cash/bank scenario, owner confirmations, exactly-once posting and reload |
| system | 150 products, 25 suppliers, 40 customers, 500 sales, 100 receipts, credit and backup round trips |
| performance | 100/1,000/5,000 products; 10,000/50,000 sales; timing and heap samples |
| theme / contrast | Protected source/appearance boundaries, persisted preferences, visible panels, viewport coverage and 160 sampled theme/mode/screen states |

For one suite against an existing local server, set `ROSEACHY_BASE_URL`. `ROSEACHY_APP_ROOT` and `ROSEACHY_RESULTS_DIR` override source/results locations. `capture-audit.mjs after` captures four representative pages.

Passing sampled contrast does not certify every dynamic state. Disabled controls are excluded. Screenshots of original protected themes disable only the audit contrast layer to isolate unrelated visual regressions. Physical devices, native file handling, every input method, Safari/Firefox, and production Cloudflare headers remain outside this executable environment.
