import {parse} from 'espree';
import assert from 'node:assert/strict';
const modifiedFunctions=new Set(['inventoryCommit','parseBulkStock','refreshBatchDup','join','updates']);
const newFunctions=new Set(['bulkNumber','cachedParse','rsApplyAuditContrast']);
const newVariables=new Set(['parsedNameCache','bulkDuplicateCache','supplierSaveBusy']);
function canonical(html){
 const source=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(x=>x[1]).join('\n');
 const tree=parse(source,{ecmaVersion:2023,sourceType:'script',range:true});
 function clean(n){
  if(n===null||typeof n!=='object')return n;
  if(Array.isArray(n))return n.map(clean).filter(x=>x!==undefined);
  if(n.type==='FunctionDeclaration'&&newFunctions.has(n.id?.name))return undefined;
  if(n.type==='VariableDeclaration'&&n.declarations.length===1&&newVariables.has(n.declarations[0].id.name))return undefined;
  if(n.type==='ExpressionStatement'&&n.expression?.callee?.name==='rsApplyAuditContrast')return undefined;
  if(n.type==='ExpressionStatement'&&source.slice(...n.range).startsWith("$('supplierSaveBtn')?.addEventListener"))return {type:'ApprovedSupplierSaveHandler'};
  if(n.type==='FunctionDeclaration'&&modifiedFunctions.has(n.id?.name))return {type:'ApprovedFunction',name:n.id.name};
  if(n.type==='VariableDeclarator'&&n.id.name==='day'&&n.init?.type==='ArrowFunctionExpression')return {type:'ApprovedSavedDayProjection'};
  const out={};for(const [k,v]of Object.entries(n))if(!['range','loc','start','end','raw'].includes(k))out[k]=clean(v);
  if(out.type==='Identifier'&&out.name==='cachedParse')out.name='parse';
  return out;
 }
 return clean(tree);
}
export function verifySourceBoundary(original,current){assert.deepEqual(canonical(current),canonical(original));return {modifiedFunctions:[...modifiedFunctions],newFunctions:[...newFunctions],additionalBoundaries:['supplier save handler and in-flight flag','saved-day privacy projection','bounded name/duplicate caches','appearance contrast token call']}}
