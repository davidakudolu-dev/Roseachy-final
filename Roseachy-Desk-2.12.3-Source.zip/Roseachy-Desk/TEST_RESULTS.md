# Executed test results

**67 functional checks passed; 0 failed.** The same 67 checks also passed against
the extracted 13-file deployment ZIP. See `audit/deployment-check-summary.json`.
Static checks of all production
JavaScript also completed with no configured-rule findings.

Environment: Linux, Node.js 24.19.0, Chromium 154.0.8037.57, Python 3.12.14.
All customer, stock, bank and payment records were synthetic. The test runner
created fresh browser profiles and propagated child-command exit status.

## Executed suites

| Suite | Passed | Failed | Evidence |
| --- | ---: | ---: | --- |
| Ledger, credit and stock regression | 19 | 0 | audit/results/regression-results.json |
| Mobile/business workflows and persistence | 22 | 0 | audit/results/workflow-results.json |
| POS, refunds, compatibility and integrity | 10 | 0 | audit/results/integrity-results.json |
| Two-device signed Smart Sync | 11 | 0 | audit/results/sync-results.json |
| Offline shell, bridge and UI preservation | 5 | 0 | audit/results/platform-results.json |

The suite has no skipped or expected-failure assertions. Earlier failures against
original source are retained separately in `audit/baseline/`: 11 failed assertions
reproduced the corrected defects. Four additional sync/privacy checks were added
after the initial sync baseline. Platform offline validation served the current
local site; the baseline Android bridge comparison loaded the original bridge.

## Requested A–L relationship matrix

| Test | Observed outcome |
| --- | --- |
| A Cash sale | ₦5,000 sale deducts 5 units; cash rises ₦5,000; one ledger event. |
| B Transfer sale | ₦10,000 bank movement; no added cash; private balance still requires confirmation. |
| C Stock purchase | 20 units / ₦30,000 adds 20 stock, deducts ₦30,000 cash and adds no sales revenue. Partial supplier purchase pays ₦10,000 and leaves ₦20,000 owing. |
| D Credit purchase | ₦15,000 customer charge deducts stock once; cash and Opening Debts stay separate. |
| E Partial credit payment | ₦6,000 collection leaves ₦9,000 owing; no extra sale or stock movement. |
| F Settlement | Final ₦9,000 collection leaves zero balance; replaying its ID adds nothing. |
| G Concurrent stock | Two signed device profiles share verified 100-unit checkpoint; -10 sale and +25 purchase converge to 115 on both. |
| H Repeat sync | Same signed update imported three times; no repeated stock, credit or cash effects. |
| I Protected bank | Remote bank transaction preserves the claim, leaves owner bank unchanged, applies once after approval, and remains single after reimport. |
| J Reversal | Credit-group voids and linked refund/reversal reconcile stock and funds. Confirmed bank reversal leaves the queue. Over-refund and invalid credit void are rejected. |
| K Backup | Full Backup includes the tested domains, checksum validation and safety download. Restore recovers stock, credit and history; subsequent sync does not duplicate them. |
| L Rapid interaction | Mobile Save double-click creates one account; suggestions, quantity input, payment forms, repeated Market completion and repeated navigation preserve records. |

Additional checks include wrong PIN rejection, clearing the unlocked Financial
Desk session, real IndexedDB write-failure injection and rollback, localStorage
fallback, legacy stock migration/reload, credit limits, historical price snapshots,
POS fee destinations, internal transfer conservation, malformed imports,
unauthorized recent-history deletion, signature tampering, private-vault exclusion,
concurrent overselling discrepancies and conflicting credit-limit edits.

Original static style blocks and pre-script body markup match SHA-256 fixtures.
No duplicate live DOM identities were found. The ordinary PWA cached all 11 shell
assets and reloaded offline with its saved account. Android CSV forwarding was
verified with a bridge mock. The application has no build/code-generation step.

## Not executed or not established

- Production Cloudflare deployment, actual production headers, CDN propagation,
  and installation/update across real devices.
- Native Android WebView bridge, system file picker, filesystem permissions,
  iOS/PWA installation, physical gestures and mobile keyboards.
- Browser/process termination during every possible write boundary, disk eviction,
  every supported import/export format and every multi-device conflict combination.
- Large business-history load benchmarks, a penetration test, and reconciliation
  against actual customer records; none were supplied.
- Publishing the cloud environment or restoring it in a fresh cloud task.

These boundaries are unrun checks, not passing assertions. There are no known
failures in the executed final suites. Existing business policies, including
seven-day adjustment detail retention and local-only private domains, were kept.

## Reproduce

```sh
npm ci --prefix tests --cache /workspace/.npm --no-audit --no-fund
npm test --prefix tests
python3 tools/package.py
```

`audit/results/summary.json` records the current run and suite exit codes.
Packages are verified during ZIP creation by CRC, member list and SHA-256 content
comparison. `dist/SHA256-MANIFEST.json` lists release artifact checksums.
