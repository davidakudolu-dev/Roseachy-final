# Migration and compatibility

## Data formats retained

IndexedDB remains `roseachy_pwa_db`, database version **8**. Full Backup remains
version **30**, schema **17**. Smart Sync remains protocol **3**. Existing product,
batch, transaction, account and customer IDs are retained. There is no mandatory
database upgrade, ledger rewrite, historical revaluation or balance reset.

Changing a current selling price still does not rewrite completed sales.
Customer Credit Accounts remain distinct from Opening Debts and supplier debt.
The existing PIN, bank vault encryption and designated sync owner rules remain.

## Settlement metadata compatibility repair

Older standalone bank confirmations could save the encrypted bank posting but
omit the public settlement receipt. When the owner unlocks Financial Desk with
the existing PIN, matching authenticated decisions now regenerate missing or
outdated receipts. This applies only before enrollment or on the designated
bank-owner device. Repeating the unlock is idempotent.

The repair creates **no financial posting**, changes no transaction amount and
does not infer an approval. A changed transaction whose signature no longer
matches its decision remains subject to review. The receipt can correct a
supplier's displayed paid/outstanding status based on its already recorded
approval. The private approval history and bank amounts remain encrypted.

## More conservative import and cleanup behavior

Backup validation now rejects transaction IDs reused on different business
dates, and conflicting saved copies of the same transaction. A current draft
may still supersede its saved copy on the same date. Missing legacy IDs retain
the existing migration behavior.

A rejected backup is not silently corrected. Reconcile the source records or
use a consistent recovery copy. Existing historical discrepancies have not been
invented away, and no actual customer database was supplied for reconciliation.

The pre-existing seven-day Adjustment History detail policy is unchanged. It
does not delete the underlying saved-day ledgers, product history, stock or
external backups. Future-dated or malformed dates are retained rather than used
as evidence of expiry; malformed records remain subject to validation.

## Deployment sequence

1. Export and check a Full Backup on every real device; save recovery keys outside
   the device using the existing workflow.
2. Upload the static Pages deployment ZIP to the existing site's origin. Changing
   origins creates separate browser storage; it is not a data migration.
3. Update every participating installation through the existing PWA update prompt.
   Service-worker cache version changes to `2.12.2-integrity-audit-20261019`.
4. Confirm stock, customer balances, saved-day history and Financial Desk status
   against the backups. Unlock the owner Financial Desk to restore any missing
   older settlement receipts.
5. Continue existing signed sync enrollment/checkpoint procedures. Full Backup
   restore is intentional recovery, not a way to merge devices.

The application's existing restrictions on older protocol 1/2 sync files remain.
No new Smart Sync passphrase or re-enrollment requirement was introduced for
working protocol 3 installations. Preserve device signing keys and identities.

Keep `audit/original-upload.zip` for code rollback. Code rollback does not roll
back a browser database; use the verified Full Backup recovery workflow for data.
Publication, real-device upgrade and fresh cloud-task restoration were not
performed during this audit.
