# Roseachy Desk 2.12.3

Audited static release based on `Roseachy_Credit_Limit_Updated (1).zip`.
Reference-inspired visual styling extends the audited release. The existing
structure, application assets, PIN workflow, offline database and Smart Sync
protocol are retained. See [Visual redesign and verification](VISUAL_REDESIGN.md).

## Development

Serve this directory over HTTP for local development:

```sh
cd /workspace/Roseachy-final
python3 -m http.server 8000 --bind 127.0.0.1
```

Production uses HTTPS. There is no application build step, backend, account API,
database server, or production npm dependency. Browser records remain local to
the site's origin. Use the existing checkout; cloud tasks are already isolated
and do not need a Git worktree.

## Validation

The regression suite needs Node.js 24+, Chromium and npm:

```sh
npm ci --prefix tests --cache /workspace/.npm --no-audit --no-fund
npm test --prefix tests
```

The runner starts and stops its own local HTTP server on an available port.
Browser profiles and records are synthetic and isolated. Set `CHROMIUM_PATH`
if Chromium is installed somewhere other than `/usr/bin/chromium`.
Results are written to `.test-results/`; raw browser business fixtures are not
part of the deployment. See [tests/README.md](tests/README.md).

## Packaging and deployment

```sh
python3 tools/package.py
```

`dist/Roseachy-Desk-2.12.3-Cloudflare-Pages.zip` contains the 13 runtime files at
the ZIP root for Cloudflare Pages Direct Upload. The source ZIP also contains
tests, documentation, audit evidence, and the recoverable original upload.
Use the deployment ZIP for Pages; keep the source ZIP for development.

This is a static Cloudflare Pages project. No Workers runtime, Wrangler Worker
entry point, npm build output, or server configuration is required. The existing
`_redirects` and `_headers` files are retained. Review and upload the deployment
package through the existing Pages project; this work has not published a site.

Keep the existing production origin to retain its browser database. Export and
check a Full Backup on each device before deploying, and follow
[MIGRATION.md](MIGRATION.md). Offline PWA updates use the existing update prompt.

## Engineering deliverables

- [Audit and engineering summary](AUDIT_REPORT.md)
- [Department relationships and data ownership](RELATIONSHIPS.md)
- [Executed tests and validation boundaries](TEST_RESULTS.md)
- [Migration and compatibility](MIGRATION.md)
- [Saved cloud environment instructions](ENVIRONMENT.md)
- [Machine-readable evidence](audit/)

The GitHub repository supplied for onboarding was empty. These files came from
the uploaded ZIP. Downloadable release archives are published to the repository
with user authorization; this does not deploy the site. The saved cloud
configuration remains a separate onboarding draft.
