# Roseachy Desk internal engineering audit

Release: **2.12.2-integrity-audit**, 19 October 2026.

## Outcome and scope

The uploaded application was investigated across its storage layer, shared sales
ledger, inventory/batches, Market Desk, supplier accounts, Credit Accounts,
Financial Desk, Smart Sync, backups, PWA shell, and optional Android bridge.
Corrections target reproduced defects. Existing presentation and operational
workflows were preserved; the application was not rewritten.

The selected GitHub repository was empty. The original ZIP was retained as
`audit/original-upload.zip`, with SHA-256 provenance in `audit/provenance.json`.
All test records were synthetic. No actual business database was supplied or
modified, and no historical financial correction was fabricated.

## Verified defects corrected

| Priority | Finding | Correction and evidence |
| --- | --- | --- |
| Critical | Backup validation accepted a transaction identity reused on different business dates, allowing inconsistent history to enter the database. | Reject cross-date reuse and conflicting saved copies before restore. Keep legitimate same-day working edits and legacy missing-ID handling. The original accepted the bad fixture; the updated validator rejects it. |
| High | Confirmed standalone supplier bank payments remained unsettled because receipt creation required an enrolled sync owner. | Save settlement receipts before enrollment as well as on the designated owner device. PIN unlock also rebuilds missing receipts from matching existing authenticated decisions, without new money postings. |
| High | Storage's recent-history deletion guard called `auditInWindow` from another closure, raising `ReferenceError`; scheduled expiry failed too. | Share one retention function through the existing store API. Expired detail can be pruned; recent detail cannot be removed. Invalid dates are retained for validation instead of treated as expired. |
| High | A voided bank transaction stayed in the owner review queue even after its reversing posting had been confirmed. | Queue an absent confirmed transaction only while its posted amount still needs reversal. Confirming the reversal restores the balance once and removes the pending item. |
| Medium | A mixed cash/bank/credit sale classified its whole amount as noncash if any bank or credit portion existed. | Derive cash sales from `splitCash`, and noncash sales from `splitBank + splitCredit`. The ₦10,000 fixture now reports ₦4,000 cash and ₦6,000 noncash; cash/bank/debt effects remain correct. |
| Medium | An initial supplier payment funded by a Market advance kept the wrong funding label because a transaction ID was compared with a payment ID. | Compare `supplierPaymentId` with `initialPaymentId`. The purchase/payment retain the same advance link; only the original advance reduces shop cash. |
| Medium | Android's optional save wrapper dropped the CSV/plain format argument when forwarding non-JSON exports. | Preserve the third argument. Mock bridge regression confirms CSV forwarding. Native Android file picker behavior remains a device check. |
| Medium | Fallback metadata/settings writes swallowed storage errors and appeared to succeed. | Propagate failed `localStorage.setItem` promises. Injected quota failure is now observable to callers. |

Eleven failing baseline assertions captured these defect paths, including
multiple assertions for the same storage/settlement causes. Baseline evidence
is under `audit/baseline/`. Expanded tests include additional sync and privacy
checks beyond that baseline.

## Cleanup and consolidation

Twelve unused closure-local functions were removed after checking lexical use,
whole-document references, inline handlers and exposed APIs:

`getAllKeys`, `mirrorAll`, `setPhysicalComposition`, `reduceLooseUnits`,
`lowThreshold`, `recordProductAgg`, `availableForTx`, `posElectronicDelta`,
`parseBulkQuantity`, `rsFillPair`, `marketMetaDelta`, and `privateChanges`.

The active quantity, pricing, POS, legacy import and matching implementations
remain. Similar-looking active helpers were not treated as duplicates.
The real authoritative storage cache remains; only unused mirror globals and an
unused aggregate cache were removed. Side-effecting Active List creation and
database initialization calls were retained when their unused bindings were
removed.

Twenty-six previously reported unused bindings were eliminated, together with
the two unused mirror globals and obsolete prepared-finance state. Readability
and execution improve through specific removals:

- Reports no longer build a complete unused inventory movement result.
- Header fitting no longer performs an unused duplicate layout measurement.
- Saved-history changes no longer allocate an unused WeakMap.
- Product search and matching shed unused intermediate variables without
  changing matching rules.

No production dependency was added. The test runner has three pinned development
dependencies, stored separately under `tests/`. No broad speedup or large-data
benchmark claim is made. Rendering windows, search behavior and existing caches
were retained. Final static checks report no findings under the configured
scope, unused-binding, duplicate-key and unreachable-code rules.

## Relationships reviewed and retained

`inventoryCommit` and `RoseachyStore.atomic` remain the shared commit boundary.
Sales, purchases, payments and adjustments use existing linked transaction IDs.
Credit repayment remains a collection event: it neither creates a second sale
nor moves stock. Credit balance is derived from customer opening credit,
credit charges and repayments, separately from Opening Debts.

Financial Desk retains private encrypted postings and PIN access. A shared bank
claim is distinct from the owner's confirmed private posting. Tests cover
remote import, pending approval, approval, reversal, repeated import and private
data exclusion from shared files.

Smart Sync retains its existing signatures, common checkpoint, event identity,
causal ordering and conflict workflow. The baseline implementation already
passed concurrent stock movement/replay tests; it was preserved. Concurrent
overselling retains both sales and reports the deficit. Conflicting credit-limit
edits require explicit resolution rather than an inferred winner.

Notes, recycle-bin data and private vault details retain their existing local
privacy treatment; Full Backup includes local domains that routine Smart Sync
intentionally excludes. That exclusion was not mistaken for a missing sync write.
See [RELATIONSHIPS.md](RELATIONSHIPS.md) for the ownership map.

## Compatibility, security and residual boundaries

There is no schema or sync protocol increment, data reset, credential replacement,
new passphrase, or frontend redesign. Existing Full Backups and legacy stock
fixtures were exercised. The only compatibility repair derives settlement
metadata from existing matching approvals after PIN unlock; it does not post
money. See [MIGRATION.md](MIGRATION.md).

The original browser app is large and keeps most logic in one HTML closure.
This release does not attempt a risky module rewrite. Checks cover representative
supported business paths; they are not proof of every possible historical data
combination, multi-device conflict, browser failure or security property.
There was no real customer dataset to reconcile, no production Cloudflare
deployment, and no physical Android/iOS device execution.

The final source, tests, audit evidence and static Pages package are provided
for review. [TEST_RESULTS.md](TEST_RESULTS.md) identifies executed checks and
the remaining deployment/device validation work.
