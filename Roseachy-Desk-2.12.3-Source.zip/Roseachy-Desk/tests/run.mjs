import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const root =
  process.env.ROSEACHY_APP_ROOT ||
  fileURLToPath(new URL("../", import.meta.url));
const resultsDir =
  process.env.ROSEACHY_RESULTS_DIR || path.join(root, ".test-results");
await fs.mkdir(resultsDir, { recursive: true });
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json",
  ".png": "image/png",
  ".svg": "image/svg+xml",
};
const server = http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(
      new URL(req.url, "http://localhost").pathname,
    );
    const file = path.resolve(
      root,
      "." + (pathname === "/" ? "/index.html" : pathname),
    );
    if (!file.startsWith(path.resolve(root) + path.sep)) {
      res.writeHead(403);
      return res.end();
    }
    const body = await fs.readFile(file);
    res.writeHead(200, {
      "Content-Type": types[path.extname(file)] || "application/octet-stream",
      "Cache-Control": "no-cache",
    });
    res.end(body);
  } catch {
    res.writeHead(404);
    res.end();
  }
});
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const env = {
  ...process.env,
  ROSEACHY_APP_ROOT: root,
  ROSEACHY_RESULTS_DIR: resultsDir,
  ROSEACHY_BASE_URL: `http://127.0.0.1:${server.address().port}`,
};
const suites = [
  "static-audit.mjs",
  "regression.mjs",
  "workflow-regression.mjs",
  "integrity-regression.mjs",
  "sync-regression.mjs",
  "platform-regression.mjs",
  "visual-regression.mjs",
];
const runs = [];
try {
  for (const name of suites) {
    console.log(`\nRunning ${name}`);
    const started = Date.now();
    const exitCode = await new Promise((resolve, reject) => {
      const child = spawn(
        process.execPath,
        [fileURLToPath(new URL(name, import.meta.url))],
        { env, stdio: "inherit" },
      );
      child.on("error", reject);
      child.on("exit", (code) => resolve(code ?? 1));
    });
    runs.push({ suite: name, exitCode, durationMs: Date.now() - started });
  }
  const checks = [];
  for (const name of [
    "regression",
    "workflow",
    "integrity",
    "sync",
    "platform",
    "visual",
  ]) {
    try {
      checks.push(
        ...JSON.parse(
          await fs.readFile(
            path.join(resultsDir, name + "-results.json"),
            "utf8",
          ),
        ),
      );
    } catch {
      runs.push({ suite: name + " results", exitCode: 1 });
    }
  }
  const summary = {
    runAt: new Date().toISOString(),
    node: process.version,
    platform: process.platform,
    suites: runs,
    passed: checks.filter((x) => x.status === "passed").length,
    failed: checks.filter((x) => x.status === "failed").length,
  };
  await fs.writeFile(
    path.join(resultsDir, "summary.json"),
    JSON.stringify(summary, null, 2) + "\n",
  );
  console.log(`\n${summary.passed} checks passed; ${summary.failed} failed.`);
  process.exitCode =
    runs.some((x) => x.exitCode !== 0) || summary.failed ? 1 : 0;
} finally {
  await new Promise((resolve) => server.close(resolve));
}
