import {browser,device,root,resultsDir} from './harness.mjs';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const results=[];
async function check(name,fn){try{const detail=await fn();results.push({name,status:'passed',detail});console.log('PASS',name)}catch(e){results.push({name,status:'failed',error:e.message});console.log('FAIL',name,e.message)}}
const d=await device({mobile:true}),p=d.page;
await check('Every production script and the original DOM are byte-identical',async()=>{
 const html=await fs.readFile(root+'/index.html','utf8'),fixture=JSON.parse(await fs.readFile(new URL('./fixtures/pre-visual-sha256.json',import.meta.url),'utf8'));
 const hash=s=>createHash('sha256').update(s).digest('hex');
 assert.deepEqual([...html.matchAll(/<script\b[^>]*>[\s\S]*?<\/script>/g)].map(m=>hash(m[0])),fixture.scripts);
 assert.equal(hash(html.slice(html.indexOf('<body'),html.indexOf('<script>'))),fixture.layout);
});
await check('The reference stylesheet contains only paint and typography properties',async()=>{
 const properties=await p.evaluate(()=>{const props=[];const visit=rules=>{for(const r of rules){if(r.cssRules)visit(r.cssRules);if(r.style)props.push(...r.style)}};visit(document.getElementById('roseachy-reference-finish').sheet.cssRules);return [...new Set(props)].filter(x=>!x.startsWith('--'))});
 assert.deepEqual(properties.filter(x=>!['background-image','background-color','color','-webkit-text-fill-color','font-family','font-weight','border-radius','border-color','border-top-left-radius','border-top-right-radius','border-bottom-left-radius','border-bottom-right-radius','border-top-color','border-right-color','border-bottom-color','border-left-color','text-shadow','box-shadow'].includes(x)),[]);
});
await check('48 theme/mode/viewport combinations keep all four desks within the viewport',async()=>{
 const names=await p.evaluate(()=>auditTest.themeNames);let count=0;const failures=[];
 for(const width of [390,768,1280]){
  await p.setViewportSize({width,height:900});
  for(const theme of names)for(const colorMode of ['light','dark']){
   await p.evaluate(({theme,colorMode})=>auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode}),{theme,colorMode});
   for(const desk of ['sales','market','settings','financial']){
    await p.evaluate(desk=>auditTest.switchDesk(desk),desk);
    await p.evaluate(()=>Promise.all(document.getAnimations().filter(a=>a.effect?.getTiming().iterations!==Infinity).map(a=>a.finished.catch(()=>{}))));
    const size=await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
    if(size.scroll>width+1)failures.push({width,theme,colorMode,desk,...size});
   }
   count++;
  }
 }
 assert.deepEqual(failures,[]);return {combinations:count,deskChecks:count*4};
});
await check('Sampled fields, labels, summaries and modal text meet 4.5:1 across all themes',async()=>{
const out=[];
for(const theme of await p.evaluate(()=>auditTest.themeNames))for(const colorMode of ['light','dark']){
 await p.evaluate(({theme,colorMode})=>auditTest.applyAppearanceSettings({...auditTest.getAppearanceSettings(),theme,colorMode}),{theme,colorMode});
 const a=await p.evaluate(()=>{
 const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const c=canvas.getContext('2d',{willReadFrequently:true});
 const rgb=v=>{c.clearRect(0,0,1,1);c.fillStyle=v;c.fillRect(0,0,1,1);return [...c.getImageData(0,0,1,1).data].map((v,i)=>i===3?v/255:v)};
 const mix=(f,b)=>f.slice(0,3).map((v,i)=>v*f[3]+b[i]*(1-f[3]));
 const bg=e=>{if(!e)return [255,255,255];const s=getComputedStyle(e),col=rgb(s.backgroundColor);return col[3]===1?col.slice(0,3):mix(col,bg(e.parentElement))};
 const lum=x=>x.map(v=>v/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0);
 const cr=(f,b)=>{const x=lum(f),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
 return ['#date','#type','#ref','#note','#addBtn','.collapseHead','.collapseInner label','.card .help','.metric strong','.metric span','.marketPanel h3','.settingsGroup summary','.finPinDigit','.previewInput','.marketViewTabs button.active','.previewTabs button:not(.active)','.previewBadge','.previewCard>small'].map(sel=>{const e=document.querySelector(sel);if(!e)return null;const s=getComputedStyle(e);return {sel,ratio:cr(rgb(s.webkitTextFillColor==='currentcolor'?s.color:s.webkitTextFillColor),bg(e)),fg:s.color,bg:s.backgroundColor}}).filter(Boolean);
 });out.push({theme,colorMode,low:a.filter(x=>x.ratio<4.5),minimum:Math.min(...a.map(x=>x.ratio))});
}
assert.deepEqual(out.flatMap(x=>x.low),[]);return out.map(({theme,colorMode,minimum})=>({theme,colorMode,minimum}));
});
await check('Settings theme switching, dark mode and persisted preference still work',async()=>{
 await p.setViewportSize({width:390,height:844});
 await p.evaluate(()=>auditTest.switchDesk('settings'));
 await p.locator('[data-theme-choice="ember"]').click();
 await p.locator('[data-setting-buttons="colorMode"] [data-value="dark"]').click();
 assert.equal(await p.locator('body').getAttribute('data-theme'),'ember');
 assert.equal(await p.locator('body').getAttribute('data-color-mode'),'dark');
 await p.evaluate(()=>auditTest.ready());await p.reload();await p.waitForFunction(()=>window.auditTest&&window.__roseachyFirstUsableMs!==undefined);
 assert.equal(await p.locator('body').getAttribute('data-theme'),'ember');
 assert.equal(await p.locator('body').getAttribute('data-color-mode'),'dark');
});
await check('Existing animation and transition definitions survive the paint layer',async()=>{
 const sample=async disabled=>p.evaluate(disabled=>{document.getElementById('roseachy-reference-finish').sheet.disabled=disabled;const props=['animationName','animationDuration','animationTimingFunction','transitionProperty','transitionDuration','transitionTimingFunction','touchAction','overflowX','position'];return [...document.querySelectorAll('button,.tabInd,.collapseBody,.brandLogo,.marketPanel,.dupModal,#rsMainTabs')].map(el=>{const s=getComputedStyle(el);return props.map(k=>s[k])})},disabled);
 const before=await sample(true);const after=await sample(false);assert.deepEqual(after,before);
});
await check('Mobile tab clicks, horizontal swipes and credit modal actions remain reachable',async()=>{
 await p.evaluate(()=>auditTest.switchDesk('sales'));
 await p.locator('#tabBtnStock').click();
 await p.waitForFunction(()=>!document.getElementById('tabStock').classList.contains('hidden'));
 await p.locator('#tabBtnTx').click();
 await p.waitForFunction(()=>!document.getElementById('tabTx').classList.contains('hidden'));
 await p.evaluate(()=>{const target=document.getElementById('txEntryCard');const touch=(x)=>new Touch({identifier:1,target,clientX:x,clientY:300});target.dispatchEvent(new TouchEvent('touchstart',{bubbles:true,touches:[touch(320)],changedTouches:[touch(320)]}));target.dispatchEvent(new TouchEvent('touchmove',{bubbles:true,cancelable:true,touches:[touch(120)],changedTouches:[touch(120)]}));target.dispatchEvent(new TouchEvent('touchend',{bubbles:true,touches:[],changedTouches:[touch(60)]}));});
 await p.waitForFunction(()=>!document.getElementById('tabStock').classList.contains('hidden'),{},{timeout:3000});
 await p.locator('#creditMenuBtn').click();await p.locator('#creditMenuEntry').click();await p.locator('#creditNew').click();await p.locator('#creditName').fill('Visual verification');await p.locator('#creditConfirm').click();await p.waitForSelector('#creditAddProducts');
 assert.equal(await p.locator('#creditAddProducts').isVisible(),true);
});
await check('Browser completes UI checks without uncaught errors',async()=>assert.deepEqual(d.errors,[]));
await fs.writeFile(resultsDir+'/visual-results.json',JSON.stringify(results,null,2)+'\n');
await browser.close();process.exitCode=results.some(x=>x.status==='failed')?1:0;
