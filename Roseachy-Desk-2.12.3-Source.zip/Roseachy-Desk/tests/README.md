# Regression suite

Run `npm ci --prefix tests` followed by `npm test --prefix tests` from the project
root. Node.js 24+ and Chromium are required. Dependencies are pinned in
`package-lock.json`; none are loaded by the production application.

The runner creates its own HTTP server and uses fresh browser profiles. All
inventory, customer, payment and bank records are synthetic. PIN `1234` is only
a test fixture. Tests never read a production browser profile or real records.

`harness.mjs` intercepts the local test HTML response to expose closure internals
inside isolated browsers. Those hooks are absent from the shipped HTML and the
Cloudflare deployment ZIP. The offline suite loads the ordinary application
without instrumentation. Android bridge tests use a mock, not a native WebView.

| Suite | Coverage |
| --- | --- |
| static-audit | Scope, unused bindings, duplicate keys and unreachable code in all production scripts |
| regression | Sales, customer credit, limits, repayments, voids, inventory replay and save rollback |
| workflow-regression | Mobile forms, Market/supplier payments, backup controller, PIN, legacy data and fallback storage |
| integrity-regression | POS fees, fund transfers, refunds, import identity validation and older settlement metadata |
| sync-regression | Signed pairing, shared baseline, concurrent events, replay, credit, owner approval, shortages and conflicts |
| platform-regression | PWA install/offline reload, original layout/style hashes and Android CSV argument forwarding |

Results and the current run summary are in `.test-results/`. Each assertion
checks a business outcome, persistence result, or application boundary; the
runner propagates failed child-process status.

For optional manual investigation, an individual browser suite can use an
already running server through `ROSEACHY_BASE_URL`. `ROSEACHY_APP_ROOT` selects a
different source directory and `ROSEACHY_RESULTS_DIR` selects an output directory.

Real Android file picker/storage behavior, physical touch/swipe behavior,
Cloudflare's production response headers and installation on actual devices
still need device/deployment checks. Browser simulation does not certify them.

The `visual-regression.mjs` suite verifies the reference finish across eight themes,
light/dark modes and three viewport sizes. It also checks script/DOM preservation,
CSS scope, sampled contrast, persisted appearance choices and mobile interactions.
Original CSS hashes intentionally exclude only the named reference-finish block.
