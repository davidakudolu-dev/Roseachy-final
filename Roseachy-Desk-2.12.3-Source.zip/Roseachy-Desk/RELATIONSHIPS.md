# Department relationships and data ownership

## Existing architecture

```mermaid
flowchart TD
  Sales[Sales Desk] --> Ledger[Shared business transactions]
  Credit[Customer Credit Accounts] --> Ledger
  Market[Market Desk and supplier purchases] --> Ledger
  Ledger --> Commit[inventoryCommit and atomic storage commit]
  Commit --> Stock[Product and expiry-batch records]
  Commit --> Days[Current draft and saved days]
  Commit --> Events[Signed Smart Sync events]
  Days --> Calc[Derived sales, cash and debt summaries]
  Days --> Claims[Bank payment claims]
  Claims --> Approval[Existing owner PIN and confirmation workflow]
  Approval --> Vault[Encrypted private bank postings]
  Events --> Reconcile[Common checkpoint and explicit conflict decisions]
  Reconcile --> Commit
  Backup[Full Backup and intentional restore] <--> Store[IndexedDB persistent records]
  Commit --> Store
  Vault --> Store
```

The service worker caches application assets. It is not the database and does
not synchronize business records.

## Persistent records

| Domain | Authority and relationships |
| --- | --- |
| Product stock | `dsb_stock_v2`, record-level `stockRecords`; total units reconcile with batches. Packs and loose units are representations of total units and pack size. |
| Current day | `dsb_draft_v2`; the current transaction list and opening inventory support reversible ledger operations. |
| Historical days | `dsb_saved_v2`, record-level saved days and indexed transaction records. Viewing does not replay stock effects. |
| Customers | `roseachy_credit_customers_v1`; IDs, contact, opening customer credit and optional limit. Balances derive from linked ledger events. |
| Market/suppliers | `roseachy_market_v1`; requests, Active Lists, applied item history, supplier purchases and payments link to the shared ledger. |
| Financial Desk | `roseachy_finance_vault_v1`; private encrypted anchor, owner postings and approval decisions. Public claim provenance and settlement receipts do not contain the private vault. |
| Sync | Device identity, trusted keys, checkpoint, event records, shadows and approved resolutions under the existing synchronization stores. |
| Backups | Complete intentional recovery state, including notes, recycle bins, encrypted financial data, working forms and sync metadata. |

## Verified connections

| Connection | Behavior verified |
| --- | --- |
| Sales ↔ Inventory | A five-unit cash sale deducts five units once. Re-render/replay and credit repayment do not rededuct stock. Valid refunds restore only justified units; removing the refund reverses those units. |
| Market ↔ Inventory | A 20-unit purchase adds 20 units, updates purchase/batch records, and remains separate from sales revenue. Partial supplier payments do not change the stock receipt. |
| Sales ↔ Financial | Cash receipts affect cash; transfer receipts create the appropriate bank claim. Private bank postings wait for owner confirmation. POS fee destinations and retail/POS fund transfers reconcile separately. |
| Market ↔ Financial | Cash purchases reduce funds by the actual amount paid. Supplier credit records the obligation, and linked payment records settle it. A Market advance is spent from its allocated funds without deducting shop cash twice. |
| Credit ↔ Sales | `sale_account` is the goods event; later `credit_payment_cash`/`credit_payment_bank` is a collection. Revenue is recognized once. |
| Credit ↔ Inventory | Credit products use inventory validation and the shared commit path. Reopening, repayment and repeated sync do not repeat deductions. |
| Credit ↔ Financial | Collection decreases the customer's balance and increases the selected receipt source. Bank receipts retain owner approval. Customer credit does not enter Opening Debts. |
| Smart Sync ↔ Departments | Shared product/transaction/customer/Market events reconcile against a verified checkpoint. Reimports deduplicate event IDs; concurrent legitimate movements survive; unresolved edits and shortages stay explicit. |
| Backup/restore ↔ Persistence | Checked Full Backup restore retains stock, credit history and sync metadata. A safety copy is created first; bad input is rejected before replacement. |

## Invariants and correction boundaries

- Inventory equals a verified baseline plus legitimate receipts, sales,
  adjustments and returns. In a shortage, zero sellable stock and an explicit
  discrepancy preserve the recorded negative reconciliation position.
- Customer credit equals confirmed opening customer credit plus charge portions
  minus collections. Payments cannot exceed outstanding credit.
- Cash reflects actual receipts, payments, allocations and fund transfers.
  Moving money between Retail and POS creates no sales revenue.
- Protected bank balance reflects its encrypted anchor and authorized postings.
  Shared transfer claims do not themselves change that private balance.
- Transaction values are snapshots. Current product price changes do not change
  past sale prices.
- Same-day draft/saved copies represent one transaction. Import cannot reuse an
  identity on a different business day.

Correction mechanisms remain those already supported: current-day credit groups
can be voided together when later collections permit it; historical credit days
are archived rather than deleted. No new arbitrary account-close, historical
payment-edit, or unsupported return workflow was invented. General stock
corrections keep an audit entry; protected bank corrections require review.
